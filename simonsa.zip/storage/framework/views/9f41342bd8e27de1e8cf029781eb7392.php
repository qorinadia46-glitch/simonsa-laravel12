<?php $__env->startSection('judul', 'Riwayat Pelanggaran'); ?>
<?php $__env->startSection('subjudul', 'Urutan kejadian dari yang paling baru'); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <input class="form-control" name="q" value="<?php echo e($filter['q'] ?? ''); ?>" placeholder="Nama atau NIS">
        <select class="form-select" name="kelas">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>" <?php if(($filter['kelas'] ?? '') === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Saring</button>
    </form>

    <div class="kartu">
        <div class="kartu-isi daftar-riwayat">
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $warna = $item->poin_pelanggaran >= 25 ? 'sp3' : ($item->poin_pelanggaran >= 10 ? 'sp1' : 'aman'); ?>
                <article class="riwayat-item">
                    <div class="riwayat-no"><?php echo e($data->firstItem() + $loop->index); ?></div>
                    <div>
                        <div class="riwayat-atas">
                            <a href="<?php echo e(route('pelanggaran.show', $item)); ?>"><?php echo e($item->kategori->nama_pelanggaran); ?></a>
                            <b class="poin-angka <?php echo e($warna); ?>"><?php echo e($item->poin_pelanggaran); ?></b>
                        </div>
                        <a class="orang riwayat-orang" href="<?php echo e(route('santri.show', $item->santri)); ?>">
                            <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->santri->nama_santri, 0, 1))); ?></span>
                            <span>
                                <strong><?php echo e($item->santri->nama_santri); ?></strong>
                                <small><?php echo e($item->santri->nis); ?> · <?php echo e($item->santri->kelas); ?> · kamar <?php echo e($item->santri->kamar ?: '-'); ?></small>
                            </span>
                        </a>
                        <p><?php echo e($item->kronologi); ?></p>
                        <small><?php echo e($item->tanggal_pelanggaran->translatedFormat('d M Y')); ?> · <?php echo e($item->pengguna->nama_user); ?></small>
                        <?php if($item->tindak_lanjut): ?><div class="catatan mt-2">Tindak lanjut: <?php echo e($item->tindak_lanjut); ?></div><?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="kosong">Belum ada riwayat.</div>
            <?php endif; ?>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/pelanggaran/riwayat.blade.php ENDPATH**/ ?>