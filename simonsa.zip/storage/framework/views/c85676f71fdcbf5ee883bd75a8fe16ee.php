<?php $__env->startSection('judul', isset($surat) ? 'Ubah Surat' : 'Terbitkan Surat Peringatan'); ?>
<?php $__env->startSection('subjudul', 'Nomor kosong akan diisi otomatis'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $ubah = isset($surat);
        $idSantri = old('id_santri', $surat->id_santri ?? ($pilihan ?? ''));
        $tingkatAwal = old('tingkat_peringatan', $surat->tingkat_peringatan ?? ($tingkat ?? ''));
    ?>
    <form class="kartu kartu-isi" method="POST" action="<?php echo e($ubah ? route('surat.update', $surat) : route('surat.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($ubah): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Santri</label>
                <select class="form-select" name="id_santri" id="pilihSantri" required>
                    <option value="">Pilih santri</option>
                    <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id_santri); ?>" data-poin="<?php echo e($item->poinTerkumpul()); ?>" <?php if($idSantri == $item->id_santri): echo 'selected'; endif; ?>><?php echo e($item->nama_santri); ?> · <?php echo e($item->poinTerkumpul()); ?> poin</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tingkat</label>
                <select class="form-select" name="tingkat_peringatan" required>
                    <option value="">Pilih</option>
                    <?php $__currentLoopData = ['SP1', 'SP2', 'SP3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php if($tingkatAwal === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal surat</label>
                <input class="form-control" type="date" name="tanggal_surat" value="<?php echo e(old('tanggal_surat', isset($surat) ? $surat->tanggal_surat->format('Y-m-d') : now()->format('Y-m-d'))); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Nomor surat</label>
                <input class="form-control" name="nomor_surat" value="<?php echo e(old('nomor_surat', $surat->nomor_surat ?? '')); ?>" maxlength="50" placeholder="Kosongkan untuk nomor otomatis">
            </div>
            <div class="col-md-3">
                <label class="form-label">Total poin</label>
                <input class="form-control" type="number" name="total_poin" id="totalPoin" value="<?php echo e(old('total_poin', $surat->total_poin ?? '')); ?>" min="0">
            </div>
            <div class="col-12">
                <label class="form-label">Isi surat</label>
                <textarea class="form-control" name="isi_surat" rows="7" placeholder="Kosongkan untuk memakai template"><?php echo e(old('isi_surat', $surat->isi_surat ?? '')); ?></textarea>
            </div>
        </div>
        <div class="catatan mt-3">Keputusan sanksi akhir tetap dilakukan di luar sistem.</div>
        <div class="mt-3 d-flex gap-2">
            <button class="btn-hijau" type="submit">Simpan</button>
            <a class="btn-putih" href="<?php echo e(route('surat.index')); ?>">Batal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const pilih = document.getElementById('pilihSantri');
    const total = document.getElementById('totalPoin');
    pilih.addEventListener('change', () => {
        const poin = pilih.selectedOptions[0]?.dataset.poin;
        if (poin !== undefined) total.value = poin;
    });
    if (!total.value && pilih.value) pilih.dispatchEvent(new Event('change'));
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\surat\form.blade.php ENDPATH**/ ?>