<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('judul', 'Dashboard'); ?> · SIMONSA</title>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/simonsa.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.css')); ?>">
</head>
<body>
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="backdrop" id="backdrop"></div>
    <div class="main">
        <header class="topbar">
            <button class="menu-btn" id="toggleSidebar" type="button" aria-label="Menu"><i class="bi bi-list"></i></button>
            <?php if($logoUrl): ?>
                <img class="logo-top" src="<?php echo e($logoUrl); ?>" alt="Logo pondok">
            <?php else: ?>
                <div class="logo-top logo-fallback">S</div>
            <?php endif; ?>
            <div>
                <h1><?php echo $__env->yieldContent('judul', 'Dashboard'); ?></h1>
                <?php if (! empty(trim($__env->yieldContent('subjudul')))): ?><p><?php echo $__env->yieldContent('subjudul'); ?></p><?php endif; ?>
            </div>
            <?php if(auth()->user()->petugas()): ?>
                <a class="lonceng" href="<?php echo e(route('notifikasi.index')); ?>" aria-label="Notifikasi">
                    <i class="bi bi-bell"></i>
                    <?php if(($jumlahNotif ?? 0) > 0): ?><em><?php echo e($jumlahNotif); ?></em><?php endif; ?>
                </a>
            <?php endif; ?>
        </header>
        <div class="isi">
            <?php echo $__env->make('partials.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php if (! empty(trim($__env->yieldContent('aksi')))): ?>
                <div class="page-head">
                    <div></div>
                    <div class="page-actions no-print"><?php echo $__env->yieldContent('aksi'); ?></div>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script>
        const toggle = document.getElementById('toggleSidebar');
        const backdrop = document.getElementById('backdrop');
        const tutup = () => document.body.classList.remove('sidebar-open');
        toggle?.addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
        backdrop?.addEventListener('click', tutup);

        document.querySelectorAll('.sandi .mata').forEach((tombol) => {
            tombol.addEventListener('click', () => {
                const input = tombol.parentElement.querySelector('input');
                const buka = input.type === 'password';
                input.type = buka ? 'text' : 'password';
                tombol.querySelector('i').className = buka ? 'bi bi-eye-slash' : 'bi bi-eye';
            });
        });

        <?php if(session('sukses')): ?>
        Swal.fire({ icon: 'success', title: 'Berhasil', text: <?php echo json_encode(session('sukses'), 15, 512) ?>, confirmButtonColor: '#1b8f4a' });
        <?php elseif(session('gagal')): ?>
        Swal.fire({ icon: 'error', title: 'Gagal', text: <?php echo json_encode(session('gagal'), 15, 512) ?>, confirmButtonColor: '#b42318' });
        <?php elseif(session('peringatan')): ?>
        Swal.fire({ icon: 'warning', title: 'Perhatian', text: <?php echo json_encode(session('peringatan'), 15, 512) ?>, confirmButtonColor: '#e0a11a' });
        <?php endif; ?>

        document.querySelectorAll('form').forEach((form) => {
            const metode = form.querySelector('input[name="_method"]');
            if (metode && metode.value === 'DELETE') {
                form.addEventListener('submit', (e) => {
                    if (form.dataset.yakin === '1') return;
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Hapus data?',
                        text: 'Anda yakin ingin menghapus data ini?',
                        showCancelButton: true,
                        confirmButtonText: 'Hapus',
                        cancelButtonText: 'Batal',
                        confirmButtonColor: '#b42318',
                        cancelButtonColor: '#6b7280'
                    }).then((hasil) => {
                        if (!hasil.isConfirmed) return;
                        form.dataset.yakin = '1';
                        form.submit();
                    });
                });
            }
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\simonsa\resources\views/layouts/app.blade.php ENDPATH**/ ?>