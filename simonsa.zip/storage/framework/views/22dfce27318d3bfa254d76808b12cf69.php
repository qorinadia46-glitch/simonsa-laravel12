<?php $__env->startSection('judul', 'Detail Pelanggaran'); ?>
<?php $__env->startSection('subjudul', $pelanggaran->kategori->nama_pelanggaran); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-putih" href="<?php echo e(route('pelanggaran.index')); ?>">Kembali</a>
    <?php if(auth()->user()->admin()): ?>
        <a class="btn-putih" href="<?php echo e(route('pelanggaran.edit', $pelanggaran)); ?>">Ubah</a>
    <?php endif; ?>
    <?php if(auth()->user()->petugas()): ?>
        <a class="btn-hijau" href="<?php echo e(route('tazir.create', ['pelanggaran' => $pelanggaran->id_pelanggaran])); ?>">Catat ta'zir</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $santri = $pelanggaran->santri;
        $progres = \App\Services\PoinService::progres($santri->poinTerkumpul());
    ?>

    <section class="profil">
        <div class="kartu profil-utama">
            <div class="profil-kepala">
                <div class="inisial"><?php echo e(strtoupper(mb_substr($santri->nama_santri, 0, 1))); ?></div>
                <div>
                    <h2><a href="<?php echo e(route('santri.show', $santri)); ?>"><?php echo e($santri->nama_santri); ?></a></h2>
                    <div class="chip-bar">
                        <span class="chip">NIS <?php echo e($santri->nis); ?></span>
                        <span class="chip"><?php echo e($santri->kelas ?: 'Kelas belum diisi'); ?></span>
                        <span class="chip">Kamar <?php echo e($santri->kamar ?: '-'); ?></span>
                        <span class="chip"><?php echo e($pelanggaran->tanggal_pelanggaran->translatedFormat('d M Y')); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="kartu profil-poin">
            <div class="d-flex justify-content-between align-items-center">
                <span>Poin pelanggaran ini</span>
                <?php echo $__env->make('partials.tingkat', ['tingkat' => $santri->tingkatSaatIni()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="angka"><?php echo e($pelanggaran->poin_pelanggaran); ?></div>
            <div class="bar"><span style="width: <?php echo e($progres['persen']); ?>%"></span></div>
            <small>Akumulasi <?php echo e($santri->poinTerkumpul()); ?> poin · <?php echo e($progres['label']); ?></small>
        </div>
    </section>

    <section class="info-grid">
        <div class="kartu info-item">
            <span>Kategori</span>
            <strong><?php echo e($pelanggaran->kategori->nama_pelanggaran); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Dicatat oleh</span>
            <strong><?php echo e($pelanggaran->pengguna->nama_user); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Waktu catat</span>
            <strong><?php echo e($pelanggaran->created_at?->translatedFormat('d F Y H:i') ?: '-'); ?></strong>
        </div>
    </section>

    <div class="kartu mb-3">
        <div class="judul-bagian"><strong><i class="bi bi-card-text"></i> Kronologi</strong></div>
        <div class="kartu-isi"><p class="mb-0"><?php echo e($pelanggaran->kronologi); ?></p></div>
    </div>

    <div class="kartu mb-3">
        <div class="judul-bagian"><strong><i class="bi bi-signpost"></i> Tindak lanjut</strong></div>
        <div class="kartu-isi"><p class="mb-0"><?php echo e($pelanggaran->tindak_lanjut ?: 'Belum ada tindak lanjut.'); ?></p></div>
    </div>

    <div class="kartu">
        <div class="judul-bagian">
            <strong><i class="bi bi-exclamation-diamond"></i> Ta'zir</strong>
            <span class="text-secondary"><?php echo e($pelanggaran->tazir->count()); ?> catatan</span>
        </div>
        <div class="kartu-isi daftar-riwayat">
            <?php $__empty_1 = true; $__currentLoopData = $pelanggaran->tazir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="riwayat-item">
                    <div class="riwayat-no"><?php echo e($loop->iteration); ?></div>
                    <div>
                        <div class="riwayat-atas">
                            <strong><?php echo e($item->jenis_tazir); ?></strong>
                            <span class="lencana <?php echo e($item->status_pelaksanaan); ?>"><?php echo e($item->labelStatus()); ?></span>
                        </div>
                        <?php if($item->keterangan): ?><p><?php echo e($item->keterangan); ?></p><?php endif; ?>
                        <small><?php echo e($item->tanggal_pelaksanaan?->translatedFormat('d M Y') ?: 'Tanggal belum diisi'); ?> · <?php echo e($item->pengguna->nama_user); ?></small>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="kosong">Belum ada ta'zir untuk pelanggaran ini.</div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\pelanggaran\show.blade.php ENDPATH**/ ?>