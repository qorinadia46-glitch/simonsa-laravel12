<?php $__env->startSection('judul', 'Backup Database'); ?>
<?php $__env->startSection('subjudul'); ?>
Otomatis setiap hari pukul <?php echo e($jadwal); ?> WIB
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aksi'); ?>
    <form method="POST" action="<?php echo e(route('backup.store')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn-hijau" type="submit">Buat backup sekarang</button>
    </form>
    <a class="btn-putih" href="<?php echo e(route('backup.sql')); ?>">Unduh SQL</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="catatan mb-3">Pada komputer lokal, backup harian juga dijalankan saat aplikasi dibuka setelah jadwal. Untuk server, jalankan <code>php artisan schedule:run</code> setiap menit.</div>
    <div class="kartu mb-3">
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Waktu</th><th>Berkas</th><th>Ukuran</th><th>Jenis</th><th>Status</th><th>Petugas</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->waktu_backup->translatedFormat('d M Y H:i')); ?></td>
                        <td><?php echo e($item->nama_file); ?><div class="small text-secondary"><?php echo e($item->keterangan); ?></div></td>
                        <td><?php echo e($item->ukuranLabel()); ?></td>
                        <td><?php echo e(ucfirst($item->jenis_backup)); ?></td>
                        <td><span class="lencana <?php echo e($item->status_backup === 'berhasil' ? 'aktif' : 'belum'); ?>"><?php echo e(ucfirst($item->status_backup)); ?></span></td>
                        <td><?php echo e($item->pengguna->nama_user); ?></td>
                        <td class="aksi-baris">
                            <?php if($item->status_backup === 'berhasil'): ?>
                                <a class="btn-sm-aksi" href="<?php echo e(route('backup.unduh', $item)); ?>">Unduh</a>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('backup.destroy', $item)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn-sm-aksi bahaya">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="kosong">Belum ada backup. Backup pertama dibuat saat halaman ini atau dashboard dibuka.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>

    <form class="kartu kartu-isi" method="POST" action="<?php echo e(route('backup.pulihkan')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2 class="h5">Pulihkan database</h2>
        <p class="text-secondary">Unggah berkas .sqlite hasil backup. Salinan database saat ini disimpan dulu sebelum dipulihkan. Anda akan diminta masuk kembali.</p>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Berkas backup</label>
                <input class="form-control" type="file" name="berkas" accept=".sqlite,.db" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Ketik PULIHKAN</label>
                <input class="form-control" name="konfirmasi" required>
            </div>
        </div>
        <button class="btn-hitam mt-3" type="submit">Pulihkan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\backup\index.blade.php ENDPATH**/ ?>