<?php $__env->startSection('judul', 'Data Santri'); ?>
<?php $__env->startSection('subjudul', 'Daftar santri dan akumulasi poin'); ?>

<?php $__env->startSection('aksi'); ?>
    <?php if(auth()->user()->admin()): ?>
        <a class="btn-hijau" href="<?php echo e(route('santri.import.form')); ?>">
            <i class="bi bi-file-earmark-excel"></i> Import Excel
        </a>

        <a class="btn-hijau" href="<?php echo e(route('santri.create')); ?>">
            <i class="bi bi-plus-lg"></i> Tambah santri
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Cari nama, NIS, kamar">
        <select class="form-select" name="kelas">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>" <?php if(request('kelas') === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select class="form-select" name="status">
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['aktif' => 'Aktif', 'nonaktif' => 'Nonaktif', 'alumni' => 'Alumni']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($nilai); ?>" <?php if(request('status') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>

    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead>
                    <tr><th class="kolom-no">No</th><th>Santri</th><th>Kelas</th><th>Kamar</th><th>Poin</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $tingkat = $santri->tingkatSaatIni();
                        $warna = $tingkat ? strtolower($tingkat) : 'aman';
                    ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $santri)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($santri->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($santri->nama_santri); ?></strong>
                                    <small>NIS <?php echo e($santri->nis); ?></small>
                                </span>
                            </a>
                        </td>
                        <td><?php echo e($santri->kelas ?: '-'); ?></td>
                        <td><?php echo e($santri->kamar ?: '-'); ?></td>
                        <td>
                            <div class="poin-sel">
                                <b class="poin-angka <?php echo e($warna); ?>"><?php echo e($santri->poinTerkumpul()); ?></b>
                                <?php echo $__env->make('partials.tingkat', ['tingkat' => $tingkat], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </td>
                        <td><span class="lencana <?php echo e($santri->status); ?>"><?php echo e(ucfirst($santri->status)); ?></span></td>
                        <td class="aksi-baris">
                            <a class="btn-sm-aksi" href="<?php echo e(route('santri.show', $santri)); ?>">Riwayat</a>
                            <?php if(auth()->user()->admin()): ?>
                                <a class="btn-sm-aksi" href="<?php echo e(route('santri.edit', $santri)); ?>">Ubah</a>
                                <form method="POST" action="<?php echo e(route('santri.destroy', $santri)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="kosong">Belum ada data santri.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/santri/index.blade.php ENDPATH**/ ?>