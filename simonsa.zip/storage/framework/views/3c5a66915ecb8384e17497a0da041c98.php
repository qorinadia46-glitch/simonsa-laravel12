<?php $__env->startSection('judul', 'Dashboard'); ?>
<?php $__env->startSection('subjudul', 'Ringkasan ketertiban santri hari ini'); ?>

<?php $__env->startSection('content'); ?>
    <div class="stat-grid">
        <article class="stat hijau">
            <div>
                <span>Santri aktif</span>
                <b><?php echo e($jumlahSantri); ?></b>
                <a href="<?php echo e(route('santri.index')); ?>">Lihat data</a>
            </div>
            <div class="stat-ikon"><i class="bi bi-people"></i></div>
        </article>
        <article class="stat kuning">
            <div>
                <span>Total pelanggaran</span>
                <b><?php echo e($jumlahPelanggaran); ?></b>
                <a href="<?php echo e(route('pelanggaran.index')); ?>">Lihat data</a>
            </div>
            <div class="stat-ikon"><i class="bi bi-journal-x"></i></div>
        </article>
        <article class="stat biru">
            <div>
                <span>Pelanggaran bulan ini</span>
                <b><?php echo e($pelanggaranBulanIni); ?></b>
                <small><?php echo e(now()->translatedFormat('F Y')); ?></small>
            </div>
            <div class="stat-ikon"><i class="bi bi-calendar-event"></i></div>
        </article>
        <article class="stat hitam">
            <div>
                <span>Akumulasi poin</span>
                <b><?php echo e($totalPoin); ?></b>
                <a href="<?php echo e(route('poin.index')); ?>">Lihat poin</a>
            </div>
            <div class="stat-ikon"><i class="bi bi-123"></i></div>
        </article>
        <article class="stat oranye">
            <div>
                <span>Surat peringatan</span>
                <b><?php echo e($jumlahSurat); ?></b>
                <?php if(auth()->user()->petugas()): ?><a href="<?php echo e(route('surat.index')); ?>">Kelola surat</a><?php else: ?><small>Diterbitkan petugas</small><?php endif; ?>
            </div>
            <div class="stat-ikon"><i class="bi bi-envelope-paper"></i></div>
        </article>
        <article class="stat ungu">
            <div>
                <span>Ta'zir belum selesai</span>
                <b><?php echo e($tazirBerjalan); ?></b>
                <?php if(auth()->user()->petugas()): ?><a href="<?php echo e(route('tazir.index')); ?>">Lihat ta'zir</a><?php else: ?><small>Dipantau keamanan</small><?php endif; ?>
            </div>
            <div class="stat-ikon"><i class="bi bi-exclamation-diamond"></i></div>
        </article>
        <article class="stat merah">
            <div>
                <span>Santri mencapai SP</span>
                <b><?php echo e($jumlahSp); ?></b>
                <a href="<?php echo e(route('poin.index')); ?>">Lihat akumulasi</a>
            </div>
            <div class="stat-ikon"><i class="bi bi-flag"></i></div>
        </article>
        <article class="stat toska">
            <div>
                <span>Notifikasi belum dibaca</span>
                <b><?php echo e($notifBelum); ?></b>
                <?php if(auth()->user()->petugas()): ?><a href="<?php echo e(route('notifikasi.index')); ?>">Buka notifikasi</a><?php else: ?><small>Untuk petugas</small><?php endif; ?>
            </div>
            <div class="stat-ikon"><i class="bi bi-bell"></i></div>
        </article>
    </div>

    <div class="row g-3 mt-1">
        <div class="col-lg-8">
            <div class="kartu kartu-aksen hijau">
                <div class="kartu-kepala">Pelanggaran 6 bulan terakhir</div>
                <div class="kartu-isi"><div class="chart-box"><canvas id="grafikBulan"></canvas></div></div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="kartu kartu-aksen hitam h-100">
                <div class="kartu-kepala">Sedang masuk</div>
                <div class="kartu-isi">
                    <div class="profil-nama"><?php echo e(auth()->user()->nama_user); ?></div>
                    <div class="mb-2"><?php echo e(auth()->user()->namaRole()); ?> · <?php echo e(auth()->user()->username); ?></div>
                    <div class="catatan">Keputusan sanksi dilakukan di luar sistem oleh pengasuh pondok. Aplikasi mencatat poin, surat peringatan, dan pelaksanaan ta'zir.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mt-1">
        <div class="col-lg-5">
            <div class="kartu kartu-aksen merah">
                <div class="kartu-kepala">Perlu perhatian</div>
                <div class="kartu-isi">
                    <div class="table-responsive mt-2">
                        <table class="table">
                            <thead><tr><th>Santri</th><th>Poin</th><th>Tingkat</th></tr></thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $santriSp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><a href="<?php echo e(route('santri.show', $santri)); ?>"><?php echo e($santri->nama_santri); ?></a><div class="text-secondary small"><?php echo e($santri->kelas); ?></div></td>
                                    <td><?php echo e($santri->poinTerkumpul()); ?></td>
                                    <td><?php echo $__env->make('partials.tingkat', ['tingkat' => $santri->tingkatSaatIni()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="kosong">Belum ada santri yang mencapai batas SP.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="kartu kartu-aksen kuning">
                <div class="kartu-kepala">
                    <span>Pelanggaran terbaru</span>
                    <a href="<?php echo e(route('riwayat.index')); ?>">Riwayat</a>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>Tanggal</th><th>Santri</th><th>Pelanggaran</th><th>Poin</th></tr></thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $terakhir = $catatan->first();
                                $kategoriRingkas = $catatan->pluck('kategori.nama_pelanggaran')->filter()->unique()->values();
                            ?>
                            <tr>
                                <td><?php echo e($terakhir->tanggal_pelanggaran->translatedFormat('d M Y')); ?></td>
                                <td><a href="<?php echo e(route('santri.show', $terakhir->santri)); ?>"><?php echo e($terakhir->santri->nama_santri); ?></a></td>
                                <td>
                                    <strong><?php echo e($catatan->count()); ?> pelanggaran</strong>
                                    <small class="text-secondary d-block"><?php echo e($kategoriRingkas->join(' · ')); ?></small>
                                </td>
                                <td><?php echo e($catatan->sum('poin_pelanggaran')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="kosong">Belum ada pelanggaran.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('vendor/chartjs/chart.umd.min.js')); ?>"></script>
<script>
    const warna = ['#1b8f4a', '#e0a11a', '#c2410c', '#b42318', '#14657a', '#4c3bb5', '#1aa58a', '#d4537e'];
    const bulan = <?php echo json_encode($nilaiBulan, 15, 512) ?>;
    new Chart(document.getElementById('grafikBulan'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labelBulan, 15, 512) ?>,
            datasets: [{
                label: 'Pelanggaran',
                data: bulan,
                backgroundColor: bulan.map((_, i) => warna[i % warna.length]),
                borderRadius: 8
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\dashboard.blade.php ENDPATH**/ ?>