<?php $__env->startSection('judul', isset($pengguna) ? 'Ubah Pengguna' : 'Tambah Pengguna'); ?>
<?php $__env->startSection('subjudul', isset($pengguna) ? $pengguna->nama_user : 'Password disimpan dalam bentuk terenkripsi'); ?>

<?php $__env->startSection('content'); ?>
    <?php $ubah = isset($pengguna); ?>
    <div class="form-layout">
        <form class="kartu kartu-isi formulir" method="POST" action="<?php echo e($ubah ? route('pengguna.update', $pengguna) : route('pengguna.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($ubah): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div class="bagian-form">
                <h3>Akun</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="nama_user">Nama</label>
                        <input class="form-control" id="nama_user" name="nama_user" value="<?php echo e(old('nama_user', $pengguna->nama_user ?? '')); ?>" required maxlength="100">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="username">Username</label>
                        <input class="form-control" id="username" name="username" value="<?php echo e(old('username', $pengguna->username ?? '')); ?>" required maxlength="50">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="password">Password <?php echo e($ubah ? '(kosongkan jika tidak diubah)' : ''); ?></label>
                        <div class="sandi">
                            <input class="form-control" id="password" type="password" name="password" <?php echo e($ubah ? '' : 'required'); ?> minlength="6">
                            <button class="mata" type="button" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="password_confirmation">Ulangi password</label>
                        <div class="sandi">
                            <input class="form-control" id="password_confirmation" type="password" name="password_confirmation" <?php echo e($ubah ? '' : 'required'); ?>>
                            <button class="mata" type="button" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bagian-form">
                <h3>Akses</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="role">Role</label>
                        <select class="form-select" id="role" name="role">
                            <?php $__currentLoopData = ['admin' => 'Admin', 'keamanan' => 'Keamanan', 'lurah' => 'Lurah Pondok', 'pengasuh' => 'Pengasuh Pondok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nilai); ?>" <?php if(old('role', $pengguna->role ?? 'keamanan') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="status">Status</label>
                        <select class="form-select" id="status" name="status">
                            <?php $__currentLoopData = ['aktif' => 'Aktif', 'nonaktif' => 'Nonaktif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nilai); ?>" <?php if(old('status', $pengguna->status ?? 'aktif') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-aksi">
                <button class="btn-hijau" type="submit">Simpan</button>
                <a class="btn-putih" href="<?php echo e(route('pengguna.index')); ?>">Batal</a>
            </div>
        </form>
        <aside class="kartu pratinjau">
            <div class="inisial" id="pratinjau-inisial"><?php echo e($ubah ? strtoupper(mb_substr($pengguna->nama_user, 0, 1)) : 'P'); ?></div>
            <strong id="pratinjau-nama"><?php echo e($ubah ? $pengguna->nama_user : 'Nama pengguna'); ?></strong>
            <div class="chip-bar justify-content-center">
                <span class="chip" id="pratinjau-user"><?php echo e($ubah ? $pengguna->username : 'username'); ?></span>
                <span class="chip" id="pratinjau-role">Keamanan</span>
            </div>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const isi = (id, teks) => { document.getElementById(id).textContent = teks; };
    const segar = () => {
        const nama = document.getElementById('nama_user').value.trim();
        const role = document.getElementById('role');
        isi('pratinjau-nama', nama || 'Nama pengguna');
        isi('pratinjau-inisial', (nama || 'P').charAt(0).toUpperCase());
        isi('pratinjau-user', document.getElementById('username').value.trim() || 'username');
        isi('pratinjau-role', role.selectedOptions[0].textContent);
    };
    ['nama_user', 'username', 'role'].forEach((id) => {
        document.getElementById(id).addEventListener('input', segar);
        document.getElementById(id).addEventListener('change', segar);
    });
    segar();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/pengguna/form.blade.php ENDPATH**/ ?>