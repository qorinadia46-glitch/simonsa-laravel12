<?php $__env->startSection('judul', 'Pengaturan Sistem'); ?>
<?php $__env->startSection('subjudul', 'Profil akun, batas surat peringatan, dan jadwal backup'); ?>

<?php $__env->startSection('content'); ?>
    <?php $saya = auth()->user(); ?>
    <div class="form-layout mb-3">
        <form class="kartu kartu-isi formulir" method="POST" action="<?php echo e(route('pengaturan.profil')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="bagian-form">
                <h3>Profil saya</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="nama_user">Nama</label>
                        <input class="form-control" id="nama_user" name="nama_user" value="<?php echo e(old('nama_user', $saya->nama_user)); ?>" required maxlength="100">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="username">Username</label>
                        <input class="form-control" id="username" name="username" value="<?php echo e(old('username', $saya->username)); ?>" required maxlength="50">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="password">Password baru</label>
                        <div class="sandi">
                            <input class="form-control" id="password" type="password" name="password" minlength="6" placeholder="Kosongkan jika tidak diubah">
                            <button class="mata" type="button" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="password_confirmation">Ulangi password</label>
                        <div class="sandi">
                            <input class="form-control" id="password_confirmation" type="password" name="password_confirmation">
                            <button class="mata" type="button" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-aksi">
                <button class="btn-hijau" type="submit">Simpan profil</button>
            </div>
        </form>
        <aside class="kartu pratinjau">
            <div class="inisial"><?php echo e(strtoupper(mb_substr($saya->nama_user, 0, 1))); ?></div>
            <strong><?php echo e($saya->nama_user); ?></strong>
            <div class="chip-bar justify-content-center">
                <span class="chip"><?php echo e($saya->username); ?></span>
                <span class="chip"><?php echo e($saya->namaRole()); ?></span>
            </div>
            <p>Role dan status akun diubah dari menu Pengguna.</p>
        </aside>
    </div>

    <form class="kartu kartu-isi formulir" method="POST" action="<?php echo e(route('pengaturan.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="bagian-form">
            <h3>Identitas pondok</h3>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="nama_pondok">Nama pondok</label>
                    <input class="form-control" id="nama_pondok" name="nama_pondok" value="<?php echo e(old('nama_pondok', $nilai['nama_pondok'])); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="nama_sistem">Nama sistem</label>
                    <input class="form-control" id="nama_sistem" name="nama_sistem" value="<?php echo e(old('nama_sistem', $nilai['nama_sistem'])); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="kota_surat">Kota surat</label>
                    <input class="form-control" id="kota_surat" name="kota_surat" value="<?php echo e(old('kota_surat', $nilai['kota_surat'])); ?>" required>
                </div>
            </div>
        </div>
        <div class="bagian-form">
            <h3>Batas dan backup</h3>
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label" for="batas_sp1">Batas SP1</label>
                    <input class="form-control" id="batas_sp1" type="number" name="batas_sp1" value="<?php echo e(old('batas_sp1', $nilai['batas_sp1'])); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="batas_sp2">Batas SP2</label>
                    <input class="form-control" id="batas_sp2" type="number" name="batas_sp2" value="<?php echo e(old('batas_sp2', $nilai['batas_sp2'])); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="batas_sp3">Batas SP3</label>
                    <input class="form-control" id="batas_sp3" type="number" name="batas_sp3" value="<?php echo e(old('batas_sp3', $nilai['batas_sp3'])); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label" for="jadwal_backup">Jadwal backup (WIB)</label>
                    <input class="form-control" id="jadwal_backup" type="time" name="jadwal_backup" value="<?php echo e(old('jadwal_backup', $nilai['jadwal_backup'])); ?>" required>
                </div>
            </div>
            <div class="catatan mt-3">Backup otomatis berjalan setiap hari pada jam di atas. Keputusan sanksi tetap di luar sistem.</div>
        </div>
        <div class="form-aksi">
            <button class="btn-hijau" type="submit">Simpan pengaturan</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\pengaturan\index.blade.php ENDPATH**/ ?>