<?php $__env->startSection('judul', 'Akumulasi Poin'); ?>
<?php $__env->startSection('subjudul'); ?>
SP1 <?php echo e($batas['sp1']); ?> poin, SP2 <?php echo e($batas['sp2']); ?> poin, SP3 <?php echo e($batas['sp3']); ?> poin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Nama atau NIS">
        <select class="form-select" name="kelas">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>" <?php if(request('kelas') === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Santri</th><th>Kelas</th><th>Poin</th><th>Tingkat</th><th>Progres</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $progres = \App\Services\PoinService::progres($santri->poinTerkumpul());
                        $tingkat = $santri->tingkatSaatIni();
                        $warna = $tingkat ? strtolower($tingkat) : 'aman';
                    ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $santri)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($santri->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($santri->nama_santri); ?></strong>
                                    <small>NIS <?php echo e($santri->nis); ?></small>
                                </span>
                            </a>
                        </td>
                        <td><?php echo e($santri->kelas ?: '-'); ?></td>
                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($santri->poinTerkumpul()); ?></b></td>
                        <td><?php echo $__env->make('partials.tingkat', ['tingkat' => $tingkat], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td style="min-width:180px">
                            <div class="bar <?php echo e($warna); ?>"><span style="width: <?php echo e($progres['persen']); ?>%"></span></div>
                            <small class="text-secondary"><?php echo e($progres['label']); ?></small>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Belum ada data poin.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/poin/index.blade.php ENDPATH**/ ?>