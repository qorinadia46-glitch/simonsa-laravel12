<?php $__env->startSection('judul', "Pelaksanaan Ta'zir"); ?>
<?php $__env->startSection('subjudul', 'Catatan pembinaan setelah pelanggaran'); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-hijau" href="<?php echo e(route('tazir.create')); ?>"><i class="bi bi-plus-lg"></i> Catat ta'zir</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Jenis atau nama santri">
        <select class="form-select" name="status">
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['menunggu' => 'Menunggu', 'berjalan' => 'Berjalan', 'selesai' => 'Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($nilai); ?>" <?php if(request('status') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Santri</th><th>Pelanggaran</th><th>Ta'zir</th><th>Tanggal</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $item->pelanggaran->santri)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->pelanggaran->santri->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->pelanggaran->santri->nama_santri); ?></strong>
                                    <small><?php echo e($item->pelanggaran->santri->nis); ?> · <?php echo e($item->pelanggaran->santri->kelas); ?></small>
                                </span>
                            </a>
                        </td>
                        <td><?php echo e($item->pelanggaran->kategori->nama_pelanggaran); ?></td>
                        <td>
                            <strong><?php echo e($item->jenis_tazir); ?></strong>
                            <?php if($item->keterangan): ?><div class="deskripsi-singkat"><?php echo e($item->keterangan); ?></div><?php endif; ?>
                        </td>
                        <td><?php echo e($item->tanggal_pelaksanaan?->translatedFormat('d M Y') ?: '-'); ?></td>
                        <td><span class="lencana <?php echo e($item->status_pelaksanaan); ?>"><?php echo e($item->labelStatus()); ?></span></td>
                        <td class="aksi-baris">
                            <a class="btn-sm-aksi" href="<?php echo e(route('tazir.edit', $item)); ?>">Ubah</a>
                            <?php if(auth()->user()->admin()): ?>
                                <form method="POST" action="<?php echo e(route('tazir.destroy', $item)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="kosong">Belum ada data ta'zir.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\tazir\index.blade.php ENDPATH**/ ?>