<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk · SIMONSA</title>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/simonsa.css')); ?>">
</head>
<body class="halaman-login" style="--foto-login: url('<?php echo e(asset('img/4260901105.webp')); ?>')">
    <main class="login-box">
        <div class="login-logo">
            <?php if($logoUrl): ?>
                <img src="<?php echo e($logoUrl); ?>" alt="Logo pondok">
            <?php else: ?>
                <div class="logo-fallback">S</div>
            <?php endif; ?>
        </div>
        <h1>SIMONSA</h1>
        <p class="lembaga"><?php echo e($namaPondok); ?></p>
        <?php echo $__env->make('partials.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label" for="username">Username</label>
                <div class="bidang">
                    <i class="bi bi-person"></i>
                    <input class="form-control" id="username" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required autofocus>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <div class="bidang sandi">
                    <i class="bi bi-lock"></i>
                    <input class="form-control" id="password" name="password" type="password" placeholder="Password" required>
                    <button class="mata" type="button" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button>
                </div>
            </div>
            <button class="btn-hijau w-100 justify-content-center" type="submit" style="height:48px">Masuk</button>
        </form>
    </main>
    <script>
        document.querySelectorAll('.sandi .mata').forEach((tombol) => {
            tombol.addEventListener('click', () => {
                const input = tombol.parentElement.querySelector('input');
                const buka = input.type === 'password';
                input.type = buka ? 'text' : 'password';
                tombol.querySelector('i').className = buka ? 'bi bi-eye-slash' : 'bi bi-eye';
            });
        });
    </script>
</body>
</html>
<?php /**PATH D:\laragon\www\simonsa\resources\views/auth/login.blade.php ENDPATH**/ ?>