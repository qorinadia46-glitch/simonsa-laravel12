<?php $__env->startSection('judul', 'Laporan dan Grafik'); ?>
<?php $__env->startSection('subjudul', 'Rekap pelanggaran sesuai saringan'); ?>

<?php $__env->startSection('aksi'); ?>
    <?php if(auth()->user()->admin()): ?>
        <div class="dropdown">
            <button class="btn-hijau dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-download"></i> Unduh Data
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <?php $__currentLoopData = $pilihanLaporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('laporan.index', array_merge($filter, ['jenis' => $jenis]))); ?>">
                            <i class="bi bi-file-earmark-excel text-success me-2"></i><?php echo e($label); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <button class="btn-hijau" id="cetakLaporan" type="button" data-url="<?php echo e(route('laporan.cetak')); ?>" data-token="<?php echo e(csrf_token()); ?>">Cetak laporan</button>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header class="kop-cetak">
        <?php if($logoUrl): ?>
            <img src="<?php echo e($logoUrl); ?>" alt="Logo pondok">
        <?php endif; ?>
        <div>
            <div class="merek">SIMONSA</div>
            <strong><?php echo e($namaPondok); ?></strong>
            <p>Sistem Monitoring Pelanggaran Santri</p>
        </div>
        <div class="judul-cetak">
            <b><?php echo e($jenisLaporan ? strtoupper($pilihanLaporan[$jenisLaporan]) : 'LAPORAN PELANGGARAN SANTRI'); ?></b>
            <span>Dicetak <?php echo e(now()->translatedFormat('d F Y H:i')); ?> WIB</span>
        </div>
    </header>

    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <?php if($jenisLaporan): ?>
            <input type="hidden" name="jenis" value="<?php echo e($jenisLaporan); ?>">
        <?php endif; ?>
        <input class="form-control" name="q" value="<?php echo e($filter['q'] ?? ''); ?>" placeholder="Nama atau NIS">
        <select class="form-select" name="id_kategori">
            <option value="">Semua kategori</option>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id_kategori); ?>" <?php if(($filter['id_kategori'] ?? '') == $item->id_kategori): echo 'selected'; endif; ?>><?php echo e($item->nama_pelanggaran); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select class="form-select" name="kelas">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>" <?php if(($filter['kelas'] ?? '') === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input class="form-control" type="date" name="dari" value="<?php echo e($filter['dari'] ?? ''); ?>">
        <input class="form-control" type="date" name="sampai" value="<?php echo e($filter['sampai'] ?? ''); ?>">
        <button class="btn-hijau" type="submit">Terapkan</button>
    </form>

    <?php if($jenisLaporan): ?>
        <section class="kartu kartu-aksen" id="pratinjau">
            <div class="kartu-isi">
                <h2 class="h5 mb-1"><?php echo e($pilihanLaporan[$jenisLaporan]); ?></h2>
                <p class="text-muted mb-3"><?php echo e($pratinjau->total()); ?> santri ditemukan. Pilih santri untuk menentukan isi unduhan.</p>

                <?php $__errorArgs = ['santri_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <form method="POST" action="<?php echo e(route('laporan.unduh-pilihan')); ?>" id="formUnduhPilihan">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="jenis" value="<?php echo e($jenisLaporan); ?>">
                    <?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaFilter => $nilaiFilter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="<?php echo e($namaFilter); ?>" value="<?php echo e($nilaiFilter); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="d-flex align-items-center flex-wrap gap-3 mb-3 no-print">
                        <label class="form-check mb-0">
                            <input class="form-check-input" type="checkbox" name="semua_santri" value="1" id="pilihSemuaHasil">
                            <span class="form-check-label">Pilih semua hasil</span>
                        </label>
                        <label class="form-check mb-0">
                            <input class="form-check-input" type="checkbox" id="pilihHalaman">
                            <span class="form-check-label">Pilih halaman ini</span>
                        </label>
                        <span class="text-muted" id="jumlahDipilih">0 santri dipilih</span>
                    </div>

                    <div class="table-responsive">
                        <table class="table tabel-santri laporan-santri">
                            <?php if($jenisLaporan === 'data-santri'): ?>
                                <thead><tr><th class="no-print">Pilih</th><th>NIS</th><th>Nama Santri</th><th>Jenis Kelamin</th><th>Kelas</th><th>Kamar</th><th>Status</th></tr></thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pratinjau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="no-print"><input class="form-check-input pilih-santri" type="checkbox" name="santri_ids[]" value="<?php echo e($item->id_santri); ?>" aria-label="Pilih <?php echo e($item->nama_santri); ?>"></td>
                                        <td><?php echo e($item->nis); ?></td>
                                        <td><?php echo e($item->nama_santri); ?></td>
                                        <td><?php echo e($item->jenis_kelamin); ?></td>
                                        <td><?php echo e($item->kelas); ?></td>
                                        <td><?php echo e($item->kamar); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="7" class="kosong">Tidak ada santri pada pencarian ini.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            <?php elseif($jenisLaporan === 'akumulasi-poin'): ?>
                                <thead><tr><th class="no-print">Pilih</th><th>NIS</th><th>Nama Santri</th><th>Kelas</th><th>Jumlah Pelanggaran</th><th>Akumulasi Poin</th></tr></thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pratinjau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="no-print"><input class="form-check-input pilih-santri" type="checkbox" name="santri_ids[]" value="<?php echo e($item->id_santri); ?>" aria-label="Pilih <?php echo e($item->nama_santri); ?>"></td>
                                        <td><?php echo e($item->nis); ?></td>
                                        <td><?php echo e($item->nama_santri); ?></td>
                                        <td><?php echo e($item->kelas); ?></td>
                                        <td><?php echo e($item->pelanggaran_count); ?></td>
                                        <td><?php echo e((int) $item->total_poin); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="6" class="kosong">Tidak ada santri pada pencarian ini.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            <?php elseif($jenisLaporan === 'surat-peringatan'): ?>
                                <thead><tr><th class="no-print">Pilih</th><th>NIS</th><th>Nama Santri</th><th>Jumlah Surat</th><th>Surat Terakhir</th><th>Tanggal</th><th>Total Poin</th></tr></thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pratinjau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $suratTerakhir = $item->suratPeringatan->first();
                                    ?>
                                    <tr>
                                        <td class="no-print"><input class="form-check-input pilih-santri" type="checkbox" name="santri_ids[]" value="<?php echo e($item->id_santri); ?>" aria-label="Pilih <?php echo e($item->nama_santri); ?>"></td>
                                        <td><?php echo e($item->nis); ?></td>
                                        <td><?php echo e($item->nama_santri); ?></td>
                                        <td><?php echo e($item->surat_peringatan_count); ?></td>
                                        <td><?php echo e($suratTerakhir?->tingkat_peringatan ?? '-'); ?></td>
                                        <td><?php echo e($suratTerakhir?->tanggal_surat?->format('d-m-Y') ?? '-'); ?></td>
                                        <td><?php echo e($suratTerakhir?->total_poin ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="7" class="kosong">Tidak ada surat peringatan pada pencarian ini.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            <?php else: ?>
                                <thead><tr><th class="no-print">Pilih</th><th>NIS</th><th>Nama Santri</th><th>Kelas</th><th>Jumlah Pelanggaran</th><th>Total Poin</th><th>Rincian Pelanggaran</th></tr></thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pratinjau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="no-print"><input class="form-check-input pilih-santri" type="checkbox" name="santri_ids[]" value="<?php echo e($item->id_santri); ?>" aria-label="Pilih <?php echo e($item->nama_santri); ?>"></td>
                                        <td><?php echo e($item->nis); ?></td>
                                        <td><?php echo e($item->nama_santri); ?></td>
                                        <td><?php echo e($item->kelas); ?></td>
                                        <td><?php echo e($item->jumlah_pelanggaran); ?></td>
                                        <td><?php echo e((int) $item->total_poin); ?></td>
                                        <td>
                                            <details>
                                                <summary>Lihat rincian</summary>
                                                <div class="table-responsive mt-2">
                                                    <table class="table table-sm">
                                                        <thead><tr><th>Tanggal</th><th>Jenis Pelanggaran</th><th>Poin</th><th>Keterangan</th></tr></thead>
                                                        <tbody>
                                                        <?php $__currentLoopData = $item->pelanggaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($pelanggaran->tanggal_pelanggaran->format('d-m-Y')); ?></td>
                                                                <td><?php echo e($pelanggaran->kategori->nama_pelanggaran); ?></td>
                                                                <td><?php echo e($pelanggaran->poin_pelanggaran); ?></td>
                                                                <td><?php echo e($pelanggaran->kronologi); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </details>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="7" class="kosong">Tidak ada santri pada pencarian ini.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            <?php endif; ?>
                        </table>
                    </div>

                    <div class="pager no-print"><?php echo e($pratinjau->links()); ?></div>
                    <div class="alert alert-warning mt-3 d-none no-print" id="pesanPilihSantri">
                        Pilih setidaknya satu santri atau centang semua hasil sebelum mengunduh.
                    </div>
                    <div class="d-flex justify-content-end mt-3 no-print">
                        <button class="btn-hijau" type="submit">
                            <i class="bi bi-download"></i> Unduh Laporan
                        </button>
                    </div>
                </form>
            </div>
        </section>
    <?php else: ?>
    <div class="stat-grid mb-3">
        <article class="stat hijau">
            <div><span>Kasus</span><b><?php echo e($ringkas['jumlah']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-journal-x"></i></div>
        </article>
        <article class="stat kuning">
            <div><span>Total poin</span><b><?php echo e($ringkas['poin']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-123"></i></div>
        </article>
        <article class="stat hitam">
            <div><span>Santri terlibat</span><b><?php echo e($ringkas['santri']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-people"></i></div>
        </article>
        <article class="stat merah">
            <div><span>Batas SP</span><b style="font-size:18px"><?php echo e($batas['sp1']); ?> / <?php echo e($batas['sp2']); ?> / <?php echo e($batas['sp3']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-flag"></i></div>
        </article>
    </div>

    <div class="row g-3 mb-3" id="grafik">
        <div class="col-lg-7 grafik-kolom">
            <div class="kartu kartu-isi kartu-aksen hijau">
                <strong>Jumlah pelanggaran</strong>
                <div class="chart-box mt-3"><canvas id="grafikBulan"></canvas></div>
            </div>
        </div>
        <div class="col-lg-5 grafik-kolom">
            <div class="kartu kartu-isi kartu-aksen kuning">
                <strong>Per kategori</strong>
                <div class="chart-box donat mt-3"><canvas id="grafikKategori"></canvas></div>
            </div>
        </div>
    </div>

    <div class="kartu kartu-aksen" id="tabel">
        <div class="table-responsive">
            <table class="table tabel-santri laporan-santri">
                <thead><tr><th class="kolom-no">No</th><th>Santri</th><th>Jumlah Pelanggaran</th><th>Total Poin</th><th>Tanggal Terakhir</th><th>Petugas Terakhir</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $jumlahPelanggaran = $item->pelanggaran->count();
                        $totalPoin = $item->pelanggaran->sum('poin_pelanggaran');
                        $pelanggaranTerakhir = $item->pelanggaran->first();
                        $kategoriRingkas = $item->pelanggaran->pluck('kategori.nama_pelanggaran')->filter()->unique()->values();
                        $warna = $totalPoin >= 25 ? 'sp3' : ($totalPoin >= 10 ? 'sp1' : 'aman');
                    ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $item)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_santri); ?></strong>
                                    <small><?php echo e($item->nis); ?> · <?php echo e($item->kelas); ?></small>
                                </span>
                            </a>
                        </td>
                        <td>
                            <strong><?php echo e($jumlahPelanggaran); ?> pelanggaran</strong>
                            <small class="kategori-ringkas"><?php echo e($kategoriRingkas->join(' · ')); ?></small>
                        </td>
                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($totalPoin); ?></b></td>
                        <td><?php echo e($pelanggaranTerakhir?->tanggal_pelanggaran->translatedFormat('d M Y') ?? '-'); ?></td>
                        <td><?php echo e($pelanggaranTerakhir?->pengguna?->nama_user ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Tidak ada data pada saringan ini.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager no-print"><?php echo e($data->links()); ?></div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(!$jenisLaporan): ?>
<script src="<?php echo e(asset('vendor/chartjs/chart.umd.min.js')); ?>"></script>
<script>
    const warna = ['#1b8f4a', '#e0a11a', '#c2410c', '#b42318', '#14657a', '#4c3bb5', '#1aa58a', '#d4537e', '#3d5a80', '#8a6a2f'];
    const bulan = <?php echo json_encode($chart['nilaiBulan'], 15, 512) ?>;
    new Chart(document.getElementById('grafikBulan'), {
        type: 'bar',
        data: { labels: <?php echo json_encode($chart['labelBulan'], 15, 512) ?>, datasets: [{ data: bulan, backgroundColor: bulan.map((_, i) => warna[i % warna.length]), borderRadius: 8 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
    });
    new Chart(document.getElementById('grafikKategori'), {
        type: 'doughnut',
        data: { labels: <?php echo json_encode($chart['labelKategori'], 15, 512) ?>, datasets: [{ data: <?php echo json_encode($chart['nilaiKategori'], 15, 512) ?>, backgroundColor: warna }] },
        options: {
            maintainAspectRatio: false,
            cutout: '58%',
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, padding: 8, font: { size: 11 } } }
            }
        }
    });
</script>
<?php endif; ?>
<script>
    document.getElementById('cetakLaporan')?.addEventListener('click', async (event) => {
        const tombol = event.currentTarget;
        await fetch(tombol.dataset.url, {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': tombol.dataset.token, 'Accept': 'application/json' }
        });
        window.print();
    });

    const formUnduhPilihan = document.getElementById('formUnduhPilihan');
    if (formUnduhPilihan) {
        const checkboxSemua = document.getElementById('pilihSemuaHasil');
        const checkboxHalaman = document.getElementById('pilihHalaman');
        const checkboxSantri = Array.from(formUnduhPilihan.querySelectorAll('.pilih-santri'));
        const jumlahDipilih = document.getElementById('jumlahDipilih');
        const pesanPilihSantri = document.getElementById('pesanPilihSantri');
        const parameter = new URLSearchParams(window.location.search);
        parameter.delete('page');
        const kunciPilihan = `simonsa:laporan:${parameter.toString()}`;
        const pilihanTersimpan = new Set(JSON.parse(sessionStorage.getItem(kunciPilihan) || '[]'));

        const perbaruiPilihan = () => {
            sessionStorage.setItem(kunciPilihan, JSON.stringify(Array.from(pilihanTersimpan)));
            checkboxSantri.forEach((checkbox) => {
                checkbox.checked = pilihanTersimpan.has(checkbox.value);
            });
            checkboxHalaman.checked = checkboxSantri.length > 0
                && checkboxSantri.every((checkbox) => checkbox.checked);
            jumlahDipilih.textContent = checkboxSemua.checked
                ? 'Semua hasil dipilih'
                : `${pilihanTersimpan.size} santri dipilih`;
        };

        checkboxSantri.forEach((checkbox) => {
            checkbox.addEventListener('change', () => {
                if (checkbox.checked) {
                    pilihanTersimpan.add(checkbox.value);
                } else {
                    pilihanTersimpan.delete(checkbox.value);
                }
                pesanPilihSantri.classList.add('d-none');
                perbaruiPilihan();
            });
        });

        checkboxHalaman.addEventListener('change', () => {
            checkboxSantri.forEach((checkbox) => {
                if (checkboxHalaman.checked) {
                    pilihanTersimpan.add(checkbox.value);
                } else {
                    pilihanTersimpan.delete(checkbox.value);
                }
            });
            perbaruiPilihan();
        });

        checkboxSemua.addEventListener('change', perbaruiPilihan);
        perbaruiPilihan();

        formUnduhPilihan.addEventListener('submit', (event) => {
            if (checkboxSemua.checked) return;
            if (pilihanTersimpan.size === 0) {
                event.preventDefault();
                pesanPilihSantri.classList.remove('d-none');
                return;
            }

            const terpilihDiHalaman = new Set(
                checkboxSantri.filter((checkbox) => checkbox.checked).map((checkbox) => checkbox.value)
            );
            const idsTersembunyi = new Set(
                Array.from(formUnduhPilihan.querySelectorAll('input[type="hidden"][name="santri_ids[]"]'))
                    .map((input) => input.value)
            );
            pilihanTersimpan.forEach((id) => {
                if (terpilihDiHalaman.has(id) || idsTersembunyi.has(id)) return;
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'santri_ids[]';
                input.value = id;
                formUnduhPilihan.appendChild(input);
                idsTersembunyi.add(id);
            });
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/laporan/index.blade.php ENDPATH**/ ?>