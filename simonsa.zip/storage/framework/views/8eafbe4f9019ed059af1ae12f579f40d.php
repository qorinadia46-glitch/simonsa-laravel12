<?php $__env->startSection('judul', 'Detail Surat'); ?>
<?php $__env->startSection('subjudul', $surat->nomor_surat); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-putih" href="<?php echo e(route('surat.index')); ?>">Kembali</a>
    <a class="btn-putih" href="<?php echo e(route('surat.edit', $surat)); ?>">Ubah</a>
    <a class="btn-hijau" href="<?php echo e(route('surat.cetak', $surat)); ?>" target="_blank">Cetak</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $santri = $surat->santri;
        $warna = strtolower($surat->tingkat_peringatan);
        $paragraf = preg_split("/\n\s*\n/", trim($surat->isi_surat)) ?: [];
        $daftar = $santri->pelanggaran
            ->filter(fn ($item) => $item->tanggal_pelanggaran->lte($surat->tanggal_surat))
            ->sortBy('tanggal_pelanggaran')
            ->values();
    ?>

    <section class="profil">
        <div class="kartu profil-utama">
            <div class="profil-kepala">
                <div class="inisial"><?php echo e(strtoupper(mb_substr($santri->nama_santri, 0, 1))); ?></div>
                <div>
                    <h2><a href="<?php echo e(route('santri.show', $santri)); ?>"><?php echo e($santri->nama_santri); ?></a></h2>
                    <div class="chip-bar">
                        <span class="chip">NIS <?php echo e($santri->nis); ?></span>
                        <span class="chip"><?php echo e($santri->kelas ?: 'Kelas belum diisi'); ?></span>
                        <span class="chip">Kamar <?php echo e($santri->kamar ?: '-'); ?></span>
                        <?php echo $__env->make('partials.tingkat', ['tingkat' => $surat->tingkat_peringatan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="kartu profil-poin">
            <span>Total poin surat</span>
            <div class="angka"><?php echo e($surat->total_poin); ?></div>
            <small><?php echo e($surat->tanggal_surat->translatedFormat('d F Y')); ?></small>
        </div>
    </section>

    <section class="info-grid">
        <div class="kartu info-item">
            <span>Nomor surat</span>
            <strong><?php echo e($surat->nomor_surat); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Diterbitkan oleh</span>
            <strong><?php echo e($surat->pengguna->nama_user); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Waktu catat</span>
            <strong><?php echo e($surat->created_at?->translatedFormat('d F Y H:i') ?: '-'); ?></strong>
        </div>
    </section>

    <div class="kartu mb-3">
        <div class="judul-bagian"><strong><i class="bi bi-envelope-paper"></i> Isi surat</strong></div>
        <div class="kartu-isi isi-surat-layar">
            <?php $__currentLoopData = $paragraf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($teks); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="kartu">
        <div class="judul-bagian">
            <strong><i class="bi bi-journal-x"></i> Pelanggaran sampai tanggal surat</strong>
            <span class="text-secondary"><?php echo e($daftar->count()); ?> catatan</span>
        </div>
        <div class="kartu-isi daftar-riwayat">
            <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="riwayat-item">
                    <div class="riwayat-no"><?php echo e($loop->iteration); ?></div>
                    <div>
                        <div class="riwayat-atas">
                            <a href="<?php echo e(route('pelanggaran.show', $item)); ?>"><?php echo e($item->kategori->nama_pelanggaran); ?></a>
                            <b class="poin-angka <?php echo e($warna); ?>"><?php echo e($item->poin_pelanggaran); ?></b>
                        </div>
                        <small><?php echo e($item->tanggal_pelanggaran->translatedFormat('d M Y')); ?></small>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="kosong">Belum ada catatan pelanggaran sampai tanggal surat.</div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/surat/show.blade.php ENDPATH**/ ?>