<?php $__env->startSection('judul', 'Data Pelanggaran'); ?>
<?php $__env->startSection('subjudul', 'Catatan pelanggaran yang masuk ke akumulasi poin'); ?>

<?php $__env->startSection('aksi'); ?>
    <?php if(auth()->user()->petugas()): ?>
        <a class="btn-hijau" href="<?php echo e(route('pelanggaran.create')); ?>"><i class="bi bi-plus-lg"></i> Catat pelanggaran</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
    <input
        class="form-control"
        name="q"
        value="<?php echo e($filter['q'] ?? ''); ?>"
        placeholder="Cari nama, atau NIS."
    >

    <button class="btn-hijau" type="submit">
        <i class="bi bi-search"></i> Cari
    </button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Santri</th><th>Daftar pelanggaran</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $item)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_santri); ?></strong>
                                    <small><?php echo e($item->nis); ?> · <?php echo e($item->kelas); ?></small>
                                </span>
                            </a>
                        </td>
                        <td class="daftar-pelanggaran-cell">
                            <table class="daftar-pelanggaran">
                                <thead>
                                    <tr><th>Tanggal</th><th>Kategori</th><th>Poin</th><th>Petugas</th><th>Aksi</th></tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $item->pelanggaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $warna = $pelanggaran->poin_pelanggaran >= 25 ? 'sp3' : ($pelanggaran->poin_pelanggaran >= 10 ? 'sp1' : 'aman'); ?>
                                    <tr>
                                        <td><?php echo e($pelanggaran->tanggal_pelanggaran->translatedFormat('d M Y')); ?></td>
                                        <td><?php echo e($pelanggaran->kategori->nama_pelanggaran); ?></td>
                                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($pelanggaran->poin_pelanggaran); ?></b></td>
                                        <td><?php echo e($pelanggaran->pengguna?->nama_user ?? '-'); ?></td>
                                        <td class="aksi-baris">
                                            <a class="btn-sm-aksi" href="<?php echo e(route('pelanggaran.show', $pelanggaran)); ?>">Detail</a>
                                            <?php if(auth()->user()->admin()): ?>
                                                <a class="btn-sm-aksi" href="<?php echo e(route('pelanggaran.edit', $pelanggaran)); ?>">Ubah</a>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->admin()): ?>
                                                <form method="POST" action="<?php echo e(route('pelanggaran.destroy', $pelanggaran)); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="kosong">Belum ada pelanggaran.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\pelanggaran\index.blade.php ENDPATH**/ ?>