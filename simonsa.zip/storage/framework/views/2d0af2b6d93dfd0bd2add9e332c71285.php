<?php
    $user = auth()->user();
    $awal = strtoupper(mb_substr($user->nama_user, 0, 1));
    $item = function ($label, $route, $ikon, $pola) {
        $aktif = request()->routeIs($pola) ? 'aktif' : '';
        return '<a class="'.$aktif.'" href="'.route($route).'"><i class="bi '.$ikon.'"></i><span>'.$label.'</span></a>';
    };
?>
<aside class="sidebar">
    <div class="brand">
        <?php if($logoUrl): ?>
            <img src="<?php echo e($logoUrl); ?>" alt="Logo pondok">
        <?php else: ?>
            <div class="logo-fallback">S</div>
        <?php endif; ?>
        <div>
            <strong>SIMONSA</strong>
            <span><?php echo e($namaPondok); ?></span>
        </div>
    </div>
    <nav class="menu">
        <div class="menu-grup">Utama</div>
        <?php echo $item('Dashboard', 'dashboard', 'bi-grid-1x2', 'dashboard'); ?>


        <div class="menu-grup">Data</div>
        <?php echo $item('Data Santri', 'santri.index', 'bi-people', 'santri.*'); ?>

        <?php if($user->petugas()): ?>
            <?php echo $item('Kategori Pelanggaran', 'kategori.index', 'bi-tags', 'kategori.*'); ?>

        <?php endif; ?>
        <?php echo $item('Data Pelanggaran', 'pelanggaran.index', 'bi-journal-x', 'pelanggaran.*'); ?>

        <?php if($user->petugas()): ?>
            <?php echo $item('Surat Peringatan', 'surat.index', 'bi-envelope-paper', 'surat.*'); ?>

            <?php echo $item("Ta'zir", 'tazir.index', 'bi-exclamation-diamond', 'tazir.*'); ?>

        <?php endif; ?>

        <div class="menu-grup">Pemantauan</div>
        <?php echo $item('Riwayat Pelanggaran', 'riwayat.index', 'bi-clock-history', 'riwayat.*'); ?>

        <?php echo $item('Akumulasi Poin', 'poin.index', 'bi-123', 'poin.*'); ?>

        <?php if($user->role !== 'keamanan'): ?>
            <?php echo $item('Laporan & Grafik', 'laporan.index', 'bi-bar-chart', 'laporan.*'); ?>

        <?php endif; ?>
        <?php if($user->petugas()): ?>
            <?php echo $item('Notifikasi', 'notifikasi.index', 'bi-bell', 'notifikasi.*'); ?>

        <?php endif; ?>

        <?php if($user->admin()): ?>
            <div class="menu-grup">Sistem</div>
            <?php echo $item('Pengguna', 'pengguna.index', 'bi-person-badge', 'pengguna.*'); ?>

            <?php echo $item('Log Aktivitas', 'aktivitas.index', 'bi-person-check', 'aktivitas.*'); ?>

            <?php echo $item('Pengaturan Sistem', 'pengaturan.index', 'bi-gear', 'pengaturan.*'); ?>

            <?php echo $item('Backup Database', 'backup.index', 'bi-database', 'backup.*'); ?>

        <?php endif; ?>
    </nav>
    <div class="sidebar-user">
        <div class="avatar"><?php echo e($awal); ?></div>
        <div>
            <strong><?php echo e($user->nama_user); ?></strong>
            <span><?php echo e($user->namaRole()); ?></span>
        </div>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="keluar" type="submit" title="Logout" aria-label="Logout"><i class="bi bi-box-arrow-right"></i></button>
        </form>
    </div>
</aside>
<?php /**PATH D:\laragon\www\simonsa\resources\views\partials\sidebar.blade.php ENDPATH**/ ?>