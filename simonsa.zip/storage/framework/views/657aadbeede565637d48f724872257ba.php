<?php $__env->startSection('judul', 'Pengguna'); ?>
<?php $__env->startSection('subjudul', 'Akun admin, keamanan, lurah, dan pengasuh'); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-hijau" href="<?php echo e(route('pengguna.create')); ?>"><i class="bi bi-plus-lg"></i> Tambah pengguna</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Nama atau username">
        <select class="form-select" name="role">
            <option value="">Semua role</option>
            <?php $__currentLoopData = ['admin' => 'Admin', 'keamanan' => 'Keamanan', 'lurah' => 'Lurah Pondok', 'pengasuh' => 'Pengasuh Pondok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($nilai); ?>" <?php if(request('role') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Pengguna</th><th>Role</th><th>Status</th><th>Terakhir masuk</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <div class="orang">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->nama_user, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_user); ?></strong>
                                    <small><?php echo e($item->username); ?></small>
                                </span>
                            </div>
                        </td>
                        <td><?php echo e($item->namaRole()); ?></td>
                        <td><span class="lencana <?php echo e($item->status); ?>"><?php echo e(ucfirst($item->status)); ?></span></td>
                        <td><?php echo e($item->terakhir_masuk ? \Illuminate\Support\Carbon::parse($item->terakhir_masuk)->translatedFormat('d M Y H:i') : 'Belum pernah'); ?></td>
                        <td class="aksi-baris">
                            <a class="btn-sm-aksi" href="<?php echo e(route('pengguna.edit', $item)); ?>">Ubah</a>
                            <form method="POST" action="<?php echo e(route('pengguna.destroy', $item)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Belum ada pengguna.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\pengguna\index.blade.php ENDPATH**/ ?>