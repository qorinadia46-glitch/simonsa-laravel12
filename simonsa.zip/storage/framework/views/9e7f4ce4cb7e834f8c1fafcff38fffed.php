<?php $__env->startSection('judul', 'Surat Peringatan'); ?>
<?php $__env->startSection('subjudul', 'SP1, SP2, dan SP3 yang diterbitkan petugas'); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-hijau" href="<?php echo e(route('surat.create')); ?>"><i class="bi bi-plus-lg"></i> Terbitkan surat</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Nomor, nama, atau NIS">
        <select class="form-select" name="tingkat">
            <option value="">Semua tingkat</option>
            <?php $__currentLoopData = ['SP1', 'SP2', 'SP3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tingkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tingkat); ?>" <?php if(request('tingkat') === $tingkat): echo 'selected'; endif; ?>><?php echo e($tingkat); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Surat</th><th>Tanggal</th><th>Tingkat</th><th>Poin</th><th></th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $warna = strtolower($item->tingkat_peringatan); ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('surat.show', $item)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->santri->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->santri->nama_santri); ?></strong>
                                    <small><?php echo e($item->nomor_surat); ?></small>
                                </span>
                            </a>
                        </td>
                        <td><?php echo e($item->tanggal_surat->translatedFormat('d M Y')); ?></td>
                        <td><?php echo $__env->make('partials.tingkat', ['tingkat' => $item->tingkat_peringatan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($item->total_poin); ?></b></td>
                        <td class="aksi-baris">
                            <a class="btn-sm-aksi" href="<?php echo e(route('surat.show', $item)); ?>">Detail</a>
                            <a class="btn-sm-aksi" href="<?php echo e(route('surat.cetak', $item)); ?>" target="_blank">Cetak</a>
                            <a class="btn-sm-aksi" href="<?php echo e(route('surat.edit', $item)); ?>">Ubah</a>
                            <?php if(auth()->user()->admin()): ?>
                                <form method="POST" action="<?php echo e(route('surat.destroy', $item)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Belum ada surat peringatan.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\surat\index.blade.php ENDPATH**/ ?>