<?php $__env->startSection('judul', isset($santri) ? 'Ubah Santri' : 'Tambah Santri'); ?>
<?php $__env->startSection('subjudul', isset($santri) ? $santri->nama_santri : 'Isi data induk santri'); ?>

<?php $__env->startSection('content'); ?>
    <?php $ubah = isset($santri); ?>
    <div class="form-layout">
        <form class="kartu kartu-isi formulir" method="POST" action="<?php echo e($ubah ? route('santri.update', $santri) : route('santri.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($ubah): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="bagian-form">
                <h3>Identitas</h3>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label" for="nis">NIS</label>
                        <input
    type="text"
    class="form-control"
    id="nis"
    name="nis"
    value="<?php echo e(old('nis', $santri->nis ?? '')); ?>"
    inputmode="numeric"
    pattern="[0-9]+"
    maxlength="20"
    oninput="this.value = this.value.replace(/[^0-9]/g, '')"
    required
>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label" for="nama_santri">Nama santri</label>
                        <input class="form-control" id="nama_santri" name="nama_santri" value="<?php echo e(old('nama_santri', $santri->nama_santri ?? '')); ?>" required maxlength="100">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="jenis_kelamin">Jenis kelamin</label>
                        <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                            <?php $__currentLoopData = ['Laki-laki', 'Perempuan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jk); ?>" <?php if(old('jenis_kelamin', $santri->jenis_kelamin ?? 'Laki-laki') === $jk): echo 'selected'; endif; ?>><?php echo e($jk); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="status">Status</label>
                        <select class="form-select" id="status" name="status">
                            <?php $__currentLoopData = ['aktif' => 'Aktif', 'nonaktif' => 'Nonaktif', 'alumni' => 'Alumni']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nilai); ?>" <?php if(old('status', $santri->status ?? 'aktif') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="bagian-form">
                <h3>Penempatan</h3>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label" for="kelas">Kelas</label>
                        <input class="form-control" id="kelas" name="kelas" value="<?php echo e(old('kelas', $santri->kelas ?? '')); ?>" maxlength="30" placeholder="10 MA">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="kamar">Kamar</label>
                        <input class="form-control" id="kamar" name="kamar" value="<?php echo e(old('kamar', $santri->kamar ?? '')); ?>" maxlength="50">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="tanggal_masuk">Tanggal masuk</label>
                        <input class="form-control" id="tanggal_masuk" type="date" name="tanggal_masuk" value="<?php echo e(old('tanggal_masuk', isset($santri) && $santri->tanggal_masuk ? $santri->tanggal_masuk->format('Y-m-d') : '')); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="alamat">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo e(old('alamat', $santri->alamat ?? '')); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="form-aksi">
                <button class="btn-hijau" type="submit">Simpan</button>
                <a class="btn-putih" href="<?php echo e($ubah ? route('santri.show', $santri) : route('santri.index')); ?>">Batal</a>
            </div>
        </form>

        <aside class="kartu pratinjau">
            <div class="inisial" id="pratinjau-inisial"><?php echo e($ubah ? strtoupper(mb_substr($santri->nama_santri, 0, 1)) : 'S'); ?></div>
            <strong id="pratinjau-nama"><?php echo e($ubah ? $santri->nama_santri : 'Nama santri'); ?></strong>
            <div class="chip-bar justify-content-center" id="pratinjau-chip">
                <span class="chip" id="pratinjau-nis">NIS <?php echo e($ubah ? $santri->nis : '-'); ?></span>
                <span class="chip" id="pratinjau-kelas"><?php echo e($ubah && $santri->kelas ? $santri->kelas : 'Kelas'); ?></span>
                <span class="chip" id="pratinjau-kamar">Kamar <?php echo e($ubah && $santri->kamar ? $santri->kamar : '-'); ?></span>
            </div>
            <?php if($ubah): ?>
                <a class="btn-putih" href="<?php echo e(route('santri.show', $santri)); ?>">Lihat detail</a>
            <?php else: ?>
                <p>Pratinjau ikut berubah saat data diisi.</p>
            <?php endif; ?>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const isi = (id, teks) => { document.getElementById(id).textContent = teks; };
    const nama = document.getElementById('nama_santri');
    const segar = () => {
        const n = nama.value.trim();
        isi('pratinjau-nama', n || 'Nama santri');
        isi('pratinjau-inisial', (n || 'S').charAt(0).toUpperCase());
        isi('pratinjau-nis', 'NIS ' + (document.getElementById('nis').value.trim() || '-'));
        isi('pratinjau-kelas', document.getElementById('kelas').value.trim() || 'Kelas');
        isi('pratinjau-kamar', 'Kamar ' + (document.getElementById('kamar').value.trim() || '-'));
    };
    ['nama_santri', 'nis', 'kelas', 'kamar'].forEach((id) => {
        document.getElementById(id).addEventListener('input', segar);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\santri\form.blade.php ENDPATH**/ ?>