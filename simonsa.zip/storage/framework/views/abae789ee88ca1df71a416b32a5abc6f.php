<?php $__env->startSection('judul', 'Laporan dan Grafik'); ?>
<?php $__env->startSection('subjudul', 'Rekap pelanggaran sesuai saringan'); ?>

<?php $__env->startSection('aksi'); ?>
    <?php if(auth()->user()->admin()): ?>
        <a class="btn-hijau" href="<?php echo e(route('laporan.unduh', request()->only(['q', 'id_kategori', 'kelas', 'dari', 'sampai']))); ?>">
            <i class="bi bi-file-earmark-excel"></i> Unduh Excel
        </a>
        <button class="btn-hijau" id="cetakLaporan" type="button" data-url="<?php echo e(route('laporan.cetak')); ?>" data-token="<?php echo e(csrf_token()); ?>">Cetak laporan</button>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <header class="kop-cetak">
        <?php if($logoUrl): ?>
            <img src="<?php echo e($logoUrl); ?>" alt="Logo pondok">
        <?php endif; ?>
        <div>
            <div class="merek">SIMONSA</div>
            <strong><?php echo e($namaPondok); ?></strong>
            <p>Sistem Monitoring Pelanggaran Santri</p>
        </div>
        <div class="judul-cetak">
            <b>LAPORAN PELANGGARAN SANTRI</b>
            <span>Dicetak <?php echo e(now()->translatedFormat('d F Y H:i')); ?> WIB</span>
        </div>
    </header>

    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <input class="form-control" name="q" value="<?php echo e($filter['q'] ?? ''); ?>" placeholder="Nama atau NIS">
        <select class="form-select" name="id_kategori">
            <option value="">Semua kategori</option>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id_kategori); ?>" <?php if(($filter['id_kategori'] ?? '') == $item->id_kategori): echo 'selected'; endif; ?>><?php echo e($item->nama_pelanggaran); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select class="form-select" name="kelas">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>" <?php if(($filter['kelas'] ?? '') === $item): echo 'selected'; endif; ?>><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input class="form-control" type="date" name="dari" value="<?php echo e($filter['dari'] ?? ''); ?>">
        <input class="form-control" type="date" name="sampai" value="<?php echo e($filter['sampai'] ?? ''); ?>">
        <button class="btn-hijau" type="submit">Terapkan</button>
    </form>

    <div class="stat-grid mb-3">
        <article class="stat hijau">
            <div><span>Kasus</span><b><?php echo e($ringkas['jumlah']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-journal-x"></i></div>
        </article>
        <article class="stat kuning">
            <div><span>Total poin</span><b><?php echo e($ringkas['poin']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-123"></i></div>
        </article>
        <article class="stat hitam">
            <div><span>Santri terlibat</span><b><?php echo e($ringkas['santri']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-people"></i></div>
        </article>
        <article class="stat merah">
            <div><span>Batas SP</span><b style="font-size:18px"><?php echo e($batas['sp1']); ?> / <?php echo e($batas['sp2']); ?> / <?php echo e($batas['sp3']); ?></b></div>
            <div class="stat-ikon"><i class="bi bi-flag"></i></div>
        </article>
    </div>

    <div class="row g-3 mb-3" id="grafik">
        <div class="col-lg-7 grafik-kolom">
            <div class="kartu kartu-isi kartu-aksen hijau">
                <strong>Jumlah pelanggaran</strong>
                <div class="chart-box mt-3"><canvas id="grafikBulan"></canvas></div>
            </div>
        </div>
        <div class="col-lg-5 grafik-kolom">
            <div class="kartu kartu-isi kartu-aksen kuning">
                <strong>Per kategori</strong>
                <div class="chart-box donat mt-3"><canvas id="grafikKategori"></canvas></div>
            </div>
        </div>
    </div>

    <div class="kartu kartu-aksen" id="tabel">
        <div class="table-responsive">
            <table class="table tabel-santri laporan-santri">
                <thead><tr><th class="kolom-no">No</th><th>Santri</th><th>Jumlah Pelanggaran</th><th>Total Poin</th><th>Tanggal Terakhir</th><th>Petugas Terakhir</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $jumlahPelanggaran = $item->pelanggaran->count();
                        $totalPoin = $item->pelanggaran->sum('poin_pelanggaran');
                        $pelanggaranTerakhir = $item->pelanggaran->first();
                        $kategoriRingkas = $item->pelanggaran->pluck('kategori.nama_pelanggaran')->filter()->unique()->values();
                        $warna = $totalPoin >= 25 ? 'sp3' : ($totalPoin >= 10 ? 'sp1' : 'aman');
                    ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <a class="orang" href="<?php echo e(route('santri.show', $item)); ?>">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->nama_santri, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_santri); ?></strong>
                                    <small><?php echo e($item->nis); ?> · <?php echo e($item->kelas); ?></small>
                                </span>
                            </a>
                        </td>
                        <td>
                            <strong><?php echo e($jumlahPelanggaran); ?> pelanggaran</strong>
                            <small class="kategori-ringkas"><?php echo e($kategoriRingkas->join(' · ')); ?></small>
                        </td>
                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($totalPoin); ?></b></td>
                        <td><?php echo e($pelanggaranTerakhir?->tanggal_pelanggaran->translatedFormat('d M Y') ?? '-'); ?></td>
                        <td><?php echo e($pelanggaranTerakhir?->pengguna?->nama_user ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Tidak ada data pada saringan ini.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager no-print"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('vendor/chartjs/chart.umd.min.js')); ?>"></script>
<script>
    const warna = ['#1b8f4a', '#e0a11a', '#c2410c', '#b42318', '#14657a', '#4c3bb5', '#1aa58a', '#d4537e', '#3d5a80', '#8a6a2f'];
    const bulan = <?php echo json_encode($chart['nilaiBulan'], 15, 512) ?>;
    new Chart(document.getElementById('grafikBulan'), {
        type: 'bar',
        data: { labels: <?php echo json_encode($chart['labelBulan'], 15, 512) ?>, datasets: [{ data: bulan, backgroundColor: bulan.map((_, i) => warna[i % warna.length]), borderRadius: 8 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
    });
    document.getElementById('cetakLaporan')?.addEventListener('click', async (event) => {
        const tombol = event.currentTarget;
        await fetch(tombol.dataset.url, {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': tombol.dataset.token, 'Accept': 'application/json' }
        });
        window.print();
    });
    new Chart(document.getElementById('grafikKategori'), {
        type: 'doughnut',
        data: { labels: <?php echo json_encode($chart['labelKategori'], 15, 512) ?>, datasets: [{ data: <?php echo json_encode($chart['nilaiKategori'], 15, 512) ?>, backgroundColor: warna }] },
        options: {
            maintainAspectRatio: false,
            cutout: '58%',
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, padding: 8, font: { size: 11 } } }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\laporan\index.blade.php ENDPATH**/ ?>