

<?php $__env->startSection('judul', 'Import Data Santri'); ?>
<?php $__env->startSection('subjudul', 'Import banyak data santri melalui Excel'); ?>

<?php $__env->startSection('content'); ?>

<div class="kartu kartu-isi">

    <h5>Import Data Santri Excel</h5>

    <p>
        Pilih file Excel yang berisi data santri
        untuk dimasukkan ke dalam SIMONSA.
    </p>

    <div class="alert alert-info d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div>
            <strong>Belum punya format Excel?</strong>
            <div>Unduh template, isi data mulai baris kedua tanpa mengubah judul kolom.</div>
            <small>NIS, nama santri, dan jenis kelamin wajib diisi (Laki-laki/Perempuan).</small>
        </div>
        <a href="<?php echo e(route('santri.import.template', [], false)); ?>" class="btn btn-outline-success">
            <i class="bi bi-download"></i>
            Unduh Template Excel
        </a>
    </div>

    <form action="<?php echo e(route('santri.import.proses')); ?>"
          method="POST"
          enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Pilih File Excel</label>

            <input type="file"
                   name="file"
                   class="form-control"
                   accept=".xlsx,.xls,.csv"
                   required>
        </div>

        <button type="submit" class="btn-hijau">
            <i class="bi bi-upload"></i>
            Import Sekarang
        </button>

        <a href="<?php echo e(route('santri.index')); ?>"
           class="btn-sm-aksi">
            Kembali
        </a>

    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/santri/import.blade.php ENDPATH**/ ?>