<?php $__env->startSection('judul', 'Kategori Pelanggaran'); ?>
<?php $__env->startSection('subjudul', 'Jenis pelanggaran dan bobot poin'); ?>

<?php $__env->startSection('aksi'); ?>
    <?php if(auth()->user()->admin()): ?>
        <a class="btn-hijau" href="<?php echo e(route('kategori.import.form')); ?>">
            <i class="bi bi-file-earmark-excel"></i> Import Excel
        </a>

        <a class="btn-hijau" href="<?php echo e(route('kategori.create')); ?>">
            <i class="bi bi-plus-lg"></i> Tambah Kode Pelanggaran
        </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3 no-print" method="GET">
        <input class="form-control" name="q" value="<?php echo e($kata); ?>" placeholder="Cari kode atau nama">
        <select class="form-select" name="status">
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['aktif' => 'Aktif', 'nonaktif' => 'Nonaktif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($nilai); ?>" <?php if(request('status') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead>
                    <tr><th class="kolom-no">No</th><th>Kategori</th><th>Poin</th><th>Status</th><th>Deskripsi</th><th></th></tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $warna = $item->poin >= 25 ? 'sp3' : ($item->poin >= 10 ? 'sp1' : 'aman');
                    ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td>
                            <div class="orang">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->kode_pelanggaran, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_pelanggaran); ?></strong>
                                    <small><?php echo e($item->kode_pelanggaran); ?></small>
                                </span>
                            </div>
                        </td>
                        <td><b class="poin-angka <?php echo e($warna); ?>"><?php echo e($item->poin); ?></b></td>
                        <td><span class="lencana <?php echo e($item->status); ?>"><?php echo e(ucfirst($item->status)); ?></span></td>
                        <td><div class="deskripsi-singkat"><?php echo e($item->deskripsi ?: '-'); ?></div></td>
                        <td class="aksi-baris">
                            <?php if(auth()->user()->admin()): ?>
                                <a class="btn-sm-aksi" href="<?php echo e(route('kategori.edit', $item)); ?>">Ubah</a>
                                <form method="POST" action="<?php echo e(route('kategori.destroy', $item)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-sm-aksi bahaya" type="submit">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="kosong">Belum ada kategori.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\kategori\index.blade.php ENDPATH**/ ?>