

<?php $__env->startSection('judul', 'Import Kategori Pelanggaran'); ?>
<?php $__env->startSection('subjudul', 'Import data kategori pelanggaran melalui Excel'); ?>

<?php $__env->startSection('content'); ?>
<div class="kartu kartu-isi">
    <h5>Import Kategori Pelanggaran Excel</h5>

    <p>
        Pilih file Excel yang berisi data kategori
        pelanggaran untuk dimasukkan ke database SIMONSA.
    </p>

    <div class="alert alert-info">
        Format kolom Excel:
        kode_pelanggaran, nama_pelanggaran,
        deskripsi, poin, status.
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('kategori.import.proses')); ?>"
          method="POST"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Pilih File Excel</label>
            <input type="file"
                   name="file"
                   class="form-control"
                   accept=".xlsx,.xls,.csv"
                   required>
        </div>

        <button type="submit" class="btn-hijau">
            <i class="bi bi-upload"></i> Import Sekarang
        </button>

        <a href="<?php echo e(route('kategori.index')); ?>" class="btn-sm-aksi">
            Kembali
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\kategori\import.blade.php ENDPATH**/ ?>