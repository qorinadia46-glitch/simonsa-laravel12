<?php if(session('sukses')): ?>
    <div class="alert alert-success"><?php echo e(session('sukses')); ?></div>
<?php endif; ?>
<?php if(session('peringatan')): ?>
    <div class="alert alert-warning">
        <?php echo e(session('peringatan')); ?>

        <?php if(session('tautan_sp')): ?>
            <a href="<?php echo e(session('tautan_sp')); ?>">Terbitkan surat</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php if(session('gagal')): ?>
    <div class="alert alert-danger"><?php echo e(session('gagal')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
<?php endif; ?>
<?php /**PATH D:\laragon\www\simonsa\resources\views\partials\alert.blade.php ENDPATH**/ ?>