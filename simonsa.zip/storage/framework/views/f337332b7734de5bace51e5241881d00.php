<?php
    $daftarTingkat = ['SP1', 'SP2', 'SP3'];
    $tingkat = strtoupper((string) ($tingkat ?? ''));
    $indeksTingkat = array_search($tingkat, $daftarTingkat, true);
?>
<?php if($indeksTingkat !== false): ?>
    <span class="tingkat-berurutan">
        <?php $__currentLoopData = array_slice($daftarTingkat, 0, $indeksTingkat + 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="lencana <?php echo e(strtolower($item)); ?>"><?php echo e($item); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </span>
<?php elseif($tingkat !== ''): ?>
    <span class="lencana <?php echo e(strtolower($tingkat)); ?>"><?php echo e($tingkat); ?></span>
<?php else: ?>
    <span class="lencana aman">Aman</span>
<?php endif; ?>
<?php /**PATH D:\laragon\www\simonsa\resources\views/partials/tingkat.blade.php ENDPATH**/ ?>