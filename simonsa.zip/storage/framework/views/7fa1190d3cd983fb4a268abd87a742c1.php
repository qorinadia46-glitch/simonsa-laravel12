<?php $__env->startSection('judul', isset($pelanggaran) ? 'Ubah Pelanggaran' : 'Catat Pelanggaran'); ?>
<?php $__env->startSection('subjudul', 'Poin mengikuti kategori yang dipilih'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $ubah = isset($pelanggaran);
        $idSantri = old('id_santri', $pelanggaran->id_santri ?? '');
        $santriTerpilih = $santri->firstWhere('id_santri', $idSantri);
    ?>
    <form class="kartu kartu-isi" method="POST" action="<?php echo e($ubah ? route('pelanggaran.update', $pelanggaran) : route('pelanggaran.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($ubah): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Santri</label>
                <div class="dropdown position-relative" id="pencarianSantri">
                    <input
                        class="form-control"
                        id="cariSantri"
                        type="text"
                        value="<?php echo e($santriTerpilih ? $santriTerpilih->nis.' · '.$santriTerpilih->nama_santri.' · '.$santriTerpilih->kelas : ''); ?>"
                        placeholder="Ketik nama, NIS, atau kelas santri"
                        autocomplete="off"
                        role="combobox"
                        aria-autocomplete="list"
                        aria-expanded="false"
                        aria-controls="daftarSantri"
                        required
                    >
                    <input type="hidden" name="id_santri" id="idSantri" value="<?php echo e($santriTerpilih?->id_santri ?? ''); ?>">
                    <div class="dropdown-menu w-100 autocomplete-hasil" id="daftarSantri" role="listbox">
                    <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button
                            class="dropdown-item"
                            type="button"
                            role="option"
                            data-id="<?php echo e($item->id_santri); ?>"
                            data-label="<?php echo e($item->nis); ?> · <?php echo e($item->nama_santri); ?> · <?php echo e($item->kelas); ?>"
                            data-search="<?php echo e($item->nis); ?> <?php echo e($item->nama_santri); ?> <?php echo e($item->kelas); ?>"
                        ><?php echo e($item->nis); ?> · <?php echo e($item->nama_santri); ?> · <?php echo e($item->kelas); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="dropdown-item text-muted" id="santriTidakDitemukan" hidden>Tidak ada santri yang cocok.</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <label class="form-label">Kategori</label>
                <select class="form-select" name="id_kategori" id="kategori" required>
                    <option value="">Pilih kategori</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option
             value="<?php echo e($item->id_kategori); ?>"
             data-poin="<?php echo e($item->poin); ?>"
             <?php if(old('id_kategori', $pelanggaran->id_kategori ?? '') == $item->id_kategori): echo 'selected'; endif; ?>
    >
        <?php echo e($item->kode_pelanggaran); ?> - <?php echo e($item->nama_pelanggaran); ?> (<?php echo e($item->poin); ?> poin)
    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Tanggal</label>
                <input class="form-control" type="date" name="tanggal_pelanggaran" value="<?php echo e(old('tanggal_pelanggaran', isset($pelanggaran) ? $pelanggaran->tanggal_pelanggaran->format('Y-m-d') : now()->format('Y-m-d'))); ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Poin</label>
                <input class="form-control" id="tampilPoin" value="<?php echo e($pelanggaran->poin_pelanggaran ?? '-'); ?>" readonly>
            </div>
            <div class="col-12">
                <label class="form-label">Kronologi</label>
                <textarea class="form-control" name="kronologi" rows="4" required><?php echo e(old('kronologi', $pelanggaran->kronologi ?? '')); ?></textarea>
            </div>
            <div class="col-12">
                <label class="form-label">Tindak lanjut</label>
                <textarea class="form-control" name="tindak_lanjut" rows="3"><?php echo e(old('tindak_lanjut', $pelanggaran->tindak_lanjut ?? '')); ?></textarea>
            </div>
        </div>
        <div class="mt-3 d-flex gap-2">
            <button class="btn-hijau" type="submit">Simpan</button>
            <a class="btn-putih" href="<?php echo e(route('pelanggaran.index')); ?>">Batal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const pencarianSantri = document.getElementById('pencarianSantri');
    const cariSantri = document.getElementById('cariSantri');
    const idSantri = document.getElementById('idSantri');
    const daftarSantri = document.getElementById('daftarSantri');
    const opsiSantri = Array.from(daftarSantri.querySelectorAll('[data-id]'));
    const santriTidakDitemukan = document.getElementById('santriTidakDitemukan');

    const tutupDaftarSantri = () => {
        daftarSantri.classList.remove('show');
        cariSantri.setAttribute('aria-expanded', 'false');
    };

    const tampilkanSantri = () => {
        const kataKunci = cariSantri.value.trim().toLocaleLowerCase('id');
        opsiSantri.forEach((opsi) => {
            opsi.hidden = !opsi.dataset.search.toLocaleLowerCase('id').includes(kataKunci);
        });
        santriTidakDitemukan.hidden = opsiSantri.some((opsi) => !opsi.hidden);
        daftarSantri.classList.add('show');
        cariSantri.setAttribute('aria-expanded', 'true');
    };

    cariSantri.addEventListener('focus', tampilkanSantri);
    cariSantri.addEventListener('input', () => {
        idSantri.value = '';
        cariSantri.setCustomValidity('');
        tampilkanSantri();
    });

    opsiSantri.forEach((opsi) => {
        opsi.addEventListener('click', () => {
            cariSantri.value = opsi.dataset.label;
            idSantri.value = opsi.dataset.id;
            cariSantri.setCustomValidity('');
            tutupDaftarSantri();
        });
    });

    cariSantri.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            tutupDaftarSantri();
        } else if (event.key === 'ArrowDown') {
            const opsiTerlihat = opsiSantri.find((opsi) => !opsi.hidden);
            if (opsiTerlihat) {
                event.preventDefault();
                opsiTerlihat.focus();
            }
        }
    });

    pencarianSantri.addEventListener('focusout', (event) => {
        if (!pencarianSantri.contains(event.relatedTarget)) tutupDaftarSantri();
    });

    pencarianSantri.closest('form').addEventListener('submit', (event) => {
        if (idSantri.value) return;
        event.preventDefault();
        cariSantri.setCustomValidity('Pilih santri dari daftar yang muncul.');
        cariSantri.reportValidity();
    });

    const kategori = document.getElementById('kategori');
    const poin = document.getElementById('tampilPoin');
    const isi = () => {
        const opsi = kategori.selectedOptions[0];
        poin.value = opsi?.dataset.poin || '-';
    };
    kategori.addEventListener('change', isi);
    isi();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\pelanggaran\form.blade.php ENDPATH**/ ?>