<?php $__env->startSection('judul', 'Detail Santri'); ?>
<?php $__env->startSection('subjudul', $santri->nama_santri); ?>

<?php $__env->startSection('aksi'); ?>
    <a class="btn-putih" href="<?php echo e(route('santri.index')); ?>">Kembali</a>
    <?php if(auth()->user()->admin()): ?>
        <a class="btn-putih" href="<?php echo e(route('santri.edit', $santri)); ?>">Ubah</a>
    <?php endif; ?>
    <?php if(auth()->user()->petugas()): ?>
        <a class="btn-hijau" href="<?php echo e(route('pelanggaran.create')); ?>">Catat pelanggaran</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $progres = \App\Services\PoinService::progres($santri->poinTerkumpul());
        $inisial = strtoupper(mb_substr($santri->nama_santri, 0, 1));
    ?>

    <section class="profil">
        <div class="kartu profil-utama">
            <div class="profil-kepala">
                <div class="inisial"><?php echo e($inisial); ?></div>
                <div>
                    <h2><?php echo e($santri->nama_santri); ?></h2>
                    <div class="chip-bar">
                        <span class="chip">NIS <?php echo e($santri->nis); ?></span>
                        <span class="chip"><?php echo e($santri->kelas ?: 'Kelas belum diisi'); ?></span>
                        <span class="chip">Kamar <?php echo e($santri->kamar ?: '-'); ?></span>
                        <span class="lencana <?php echo e($santri->status); ?>"><?php echo e(ucfirst($santri->status)); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="kartu profil-poin">
            <div class="d-flex justify-content-between align-items-center">
                <span>Akumulasi poin</span>
                <?php echo $__env->make('partials.tingkat', ['tingkat' => $santri->tingkatSaatIni()], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="angka"><?php echo e($santri->poinTerkumpul()); ?></div>
            <div class="bar"><span style="width: <?php echo e($progres['persen']); ?>%"></span></div>
            <small><?php echo e($progres['label']); ?> · target <?php echo e($progres['target']); ?> poin</small>
        </div>
    </section>

    <section class="info-grid">
        <div class="kartu info-item">
            <span>Jenis kelamin</span>
            <strong><?php echo e($santri->jenis_kelamin); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Tanggal masuk</span>
            <strong><?php echo e($santri->tanggal_masuk?->translatedFormat('d F Y') ?: '-'); ?></strong>
        </div>
        <div class="kartu info-item">
            <span>Alamat</span>
            <strong><?php echo e($santri->alamat ?: '-'); ?></strong>
        </div>
    </section>

    <div class="kartu mb-3">
        <div class="judul-bagian">
            <strong><i class="bi bi-journal-x"></i> Riwayat pelanggaran</strong>
            <span class="text-secondary"><?php echo e($pelanggaran->count()); ?> catatan</span>
        </div>
        <div class="kartu-isi daftar-riwayat">
            <?php $__empty_1 = true; $__currentLoopData = $pelanggaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="riwayat-item">
                    <div class="riwayat-no"><?php echo e($loop->iteration); ?></div>
                    <div>
                        <div class="riwayat-atas">
                            <a href="<?php echo e(route('pelanggaran.show', $item)); ?>"><?php echo e($item->kategori->nama_pelanggaran); ?></a>
                            <b class="poin-angka"><?php echo e($item->poin_pelanggaran); ?></b>
                        </div>
                        <p><?php echo e($item->kronologi); ?></p>
                        <small><?php echo e($item->tanggal_pelanggaran->translatedFormat('d M Y')); ?> · <?php echo e($item->pengguna->nama_user); ?></small>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="kosong">Belum ada pelanggaran.</div>
            <?php endif; ?>
        </div>
    </div>

    <?php if(auth()->user()->petugas()): ?>
        <div class="kartu">
            <div class="judul-bagian">
                <strong><i class="bi bi-envelope-paper"></i> Surat peringatan</strong>
                <span class="text-secondary"><?php echo e($surat->count()); ?> surat</span>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th class="kolom-no">No</th><th>Nomor</th><th>Tanggal</th><th>Tingkat</th><th>Poin</th><th></th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="kolom-no"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->nomor_surat); ?></td>
                            <td><?php echo e($item->tanggal_surat->translatedFormat('d M Y')); ?></td>
                            <td><?php echo $__env->make('partials.tingkat', ['tingkat' => $item->tingkat_peringatan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                            <td><b class="poin-angka"><?php echo e($item->total_poin); ?></b></td>
                            <td><a class="btn-sm-aksi" href="<?php echo e(route('surat.cetak', $item)); ?>" target="_blank">Cetak</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="kosong">Belum ada surat peringatan.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views\santri\show.blade.php ENDPATH**/ ?>