<?php $__env->startSection('judul', 'Notifikasi'); ?>
<?php $__env->startSection('subjudul', auth()->user()->admin() ? 'Semua notifikasi batas poin' : 'Notifikasi untuk akun Anda'); ?>

<?php $__env->startSection('aksi'); ?>
    <form method="POST" action="<?php echo e(route('notifikasi.baca-semua')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn-putih" type="submit">Tandai semua dibaca</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3" method="GET">
        <select class="form-select" name="status" onchange="this.form.submit()">
            <option value="">Semua</option>
            <option value="belum" <?php if(request('status') === 'belum'): echo 'selected'; endif; ?>>Belum dibaca</option>
            <option value="sudah" <?php if(request('status') === 'sudah'): echo 'selected'; endif; ?>>Sudah dibaca</option>
        </select>
    </form>

    <div class="kartu">
        <div class="kartu-isi daftar-riwayat">
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="riwayat-item <?php echo e($item->status_baca === 'belum' ? 'notif-baru' : ''); ?>">
                    <div class="riwayat-no"><?php echo e($data->firstItem() + $loop->index); ?></div>
                    <div>
                        <div class="riwayat-atas">
                            <strong><?php echo e($item->judul); ?></strong>
                            <span class="lencana <?php echo e($item->status_baca); ?>"><?php echo e($item->status_baca === 'belum' ? 'Belum dibaca' : 'Sudah dibaca'); ?></span>
                        </div>
                        <a class="orang riwayat-orang" href="<?php echo e(route('santri.show', $item->santri)); ?>">
                            <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->santri->nama_santri, 0, 1))); ?></span>
                            <span>
                                <strong><?php echo e($item->santri->nama_santri); ?></strong>
                                <small><?php echo e($item->santri->nis); ?> · <?php echo e($item->santri->kelas); ?></small>
                            </span>
                        </a>
                        <p><?php echo e($item->pesan); ?></p>
                        <small>
                            <?php echo e($item->created_at?->translatedFormat('d M Y H:i')); ?>

                            <?php if(auth()->user()->admin()): ?> · untuk <?php echo e($item->pengguna->nama_user); ?> <?php endif; ?>
                        </small>
                        <?php if($item->status_baca === 'belum'): ?>
                            <div class="aksi-baris mt-2">
                                <form method="POST" action="<?php echo e(route('notifikasi.baca', $item)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn-sm-aksi" type="submit">Tandai dibaca</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="kosong">Tidak ada notifikasi.</div>
            <?php endif; ?>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/notifikasi/index.blade.php ENDPATH**/ ?>