<?php $__env->startSection('judul', isset($kategori) ? 'Ubah Kategori' : 'Tambah Kategori'); ?>
<?php $__env->startSection('subjudul', isset($kategori) ? $kategori->nama_pelanggaran : 'Poin disalin saat pelanggaran dicatat'); ?>

<?php $__env->startSection('content'); ?>
    <?php $ubah = isset($kategori); ?>
    <div class="form-layout">
        <form class="kartu kartu-isi formulir" method="POST" action="<?php echo e($ubah ? route('kategori.update', $kategori) : route('kategori.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($ubah): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="bagian-form">
                <h3>Identitas</h3>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label" for="kode_pelanggaran">Kode</label>
                        <input class="form-control" id="kode_pelanggaran" name="kode_pelanggaran" value="<?php echo e(old('kode_pelanggaran', $kategori->kode_pelanggaran ?? '')); ?>" required maxlength="20">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label" for="nama_pelanggaran">Nama pelanggaran</label>
                        <input class="form-control" id="nama_pelanggaran" name="nama_pelanggaran" value="<?php echo e(old('nama_pelanggaran', $kategori->nama_pelanggaran ?? '')); ?>" required maxlength="150">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="status">Status</label>
                        <select class="form-select" id="status" name="status">
                            <?php $__currentLoopData = ['aktif' => 'Aktif', 'nonaktif' => 'Nonaktif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nilai); ?>" <?php if(old('status', $kategori->status ?? 'aktif') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="bagian-form">
                <h3>Bobot</h3>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label" for="poin">Poin</label>
                        <input class="form-control" id="poin" type="number" min="1" name="poin" value="<?php echo e(old('poin', $kategori->poin ?? 5)); ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="deskripsi">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?php echo e(old('deskripsi', $kategori->deskripsi ?? '')); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="form-aksi">
                <button class="btn-hijau" type="submit">Simpan</button>
                <a class="btn-putih" href="<?php echo e(route('kategori.index')); ?>">Batal</a>
            </div>
        </form>

        <aside class="kartu pratinjau">
            <div class="inisial" id="pratinjau-inisial"><?php echo e($ubah ? strtoupper(mb_substr($kategori->kode_pelanggaran, 0, 1)) : 'K'); ?></div>
            <strong id="pratinjau-nama"><?php echo e($ubah ? $kategori->nama_pelanggaran : 'Nama pelanggaran'); ?></strong>
            <div class="chip-bar justify-content-center">
                <span class="chip" id="pratinjau-kode"><?php echo e($ubah ? $kategori->kode_pelanggaran : 'Kode'); ?></span>
                <span class="chip" id="pratinjau-poin"><?php echo e(old('poin', $kategori->poin ?? 5)); ?> poin</span>
            </div>
            <p id="pratinjau-deskripsi"><?php echo e($ubah && $kategori->deskripsi ? $kategori->deskripsi : 'Deskripsi kategori muncul di sini.'); ?></p>
        </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const isi = (id, teks) => { document.getElementById(id).textContent = teks; };
    const segar = () => {
        const kode = document.getElementById('kode_pelanggaran').value.trim();
        const nama = document.getElementById('nama_pelanggaran').value.trim();
        const deskripsi = document.getElementById('deskripsi').value.trim();
        isi('pratinjau-inisial', (kode || nama || 'K').charAt(0).toUpperCase());
        isi('pratinjau-nama', nama || 'Nama pelanggaran');
        isi('pratinjau-kode', kode || 'Kode');
        isi('pratinjau-poin', (document.getElementById('poin').value || '0') + ' poin');
        isi('pratinjau-deskripsi', deskripsi || 'Deskripsi kategori muncul di sini.');
    };
    ['kode_pelanggaran', 'nama_pelanggaran', 'poin', 'deskripsi'].forEach((id) => {
        document.getElementById(id).addEventListener('input', segar);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/kategori/form.blade.php ENDPATH**/ ?>