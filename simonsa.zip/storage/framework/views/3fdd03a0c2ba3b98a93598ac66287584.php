<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tidak ditemukan · SIMONSA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/simonsa.css')); ?>">
</head>
<body style="display:grid;place-items:center;min-height:100vh;background:#101418;color:white">
    <div style="text-align:center;padding:24px">
        <div class="logo-fallback" style="margin:0 auto 16px">S</div>
        <h1>Halaman tidak ditemukan</h1>
        <a class="btn-hijau" href="<?php echo e(url('/')); ?>">Ke beranda</a>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\simonsa\resources\views\errors\404.blade.php ENDPATH**/ ?>