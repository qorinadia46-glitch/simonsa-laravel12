<?php $__env->startSection('judul', 'Log Aktivitas'); ?>
<?php $__env->startSection('subjudul', 'Riwayat masuk, menu, dan perubahan data'); ?>

<?php $__env->startSection('content'); ?>
    <form class="kartu kartu-isi filter mb-3" method="GET">
        <input class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Nama atau aktivitas">
        <select class="form-select" name="jenis">
            <option value="">Semua aktivitas</option>
            <?php $__currentLoopData = ['masuk' => 'Masuk', 'keluar' => 'Keluar', 'gagal' => 'Gagal masuk', 'lihat' => 'Melihat menu', 'tambah' => 'Tambah', 'ubah' => 'Ubah', 'hapus' => 'Hapus', 'cetak' => 'Cetak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($nilai); ?>" <?php if(request('jenis') === $nilai): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn-hijau" type="submit">Cari</button>
    </form>
    <div class="kartu">
        <div class="table-responsive">
            <table class="table tabel-santri">
                <thead><tr><th class="kolom-no">No</th><th>Tanggal</th><th>Jam</th><th>Pengguna</th><th>Aktivitas</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="kolom-no"><?php echo e($data->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($item->waktu->translatedFormat('d M Y')); ?></td>
                        <td><?php echo e($item->waktu->format('H:i')); ?></td>
                        <td>
                            <div class="orang">
                                <span class="inisial kecil"><?php echo e(strtoupper(mb_substr($item->nama_user, 0, 1))); ?></span>
                                <span>
                                    <strong><?php echo e($item->nama_user); ?></strong>
                                    <small><?php echo e($item->labelJenis()); ?></small>
                                </span>
                            </div>
                        </td>
                        <td><?php echo e($item->aktivitas); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="kosong">Belum ada aktivitas.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="pager"><?php echo e($data->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\simonsa\resources\views/aktivitas/index.blade.php ENDPATH**/ ?>